--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.18
-- Dumped by pg_dump version 9.6.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public."Users" DROP CONSTRAINT "Users_roleId_fkey";
ALTER TABLE ONLY public."SystemFunctions" DROP CONSTRAINT "SystemFunctions_parentId_fkey";
ALTER TABLE ONLY public."SystemFunctionRoles" DROP CONSTRAINT "SystemFunctionRoles_systemFunctionId_fkey";
ALTER TABLE ONLY public."SystemFunctionRoles" DROP CONSTRAINT "SystemFunctionRoles_roleId_fkey";
ALTER TABLE ONLY public."Specialities" DROP CONSTRAINT "Specialities_personTypeId_fkey";
ALTER TABLE ONLY public."Services" DROP CONSTRAINT "Services_typeId_fkey";
ALTER TABLE ONLY public."Services" DROP CONSTRAINT "Services_specialityId_fkey";
ALTER TABLE ONLY public."Services" DROP CONSTRAINT "Services_organizationId_fkey";
ALTER TABLE ONLY public."RiskFactorDiagnoses" DROP CONSTRAINT "RiskFactorDiagnoses_riskFactorId_fkey";
ALTER TABLE ONLY public."RiskFactorDiagnoses" DROP CONSTRAINT "RiskFactorDiagnoses_appointmentHistoryId_fkey";
ALTER TABLE ONLY public."Requests" DROP CONSTRAINT "Requests_userId_fkey";
ALTER TABLE ONLY public."Requests" DROP CONSTRAINT "Requests_requestTypeId_fkey";
ALTER TABLE ONLY public."Requests" DROP CONSTRAINT "Requests_activityTypeId_fkey";
ALTER TABLE ONLY public."Ratings" DROP CONSTRAINT "Ratings_userId_fkey";
ALTER TABLE ONLY public."Ratings" DROP CONSTRAINT "Ratings_serviceId_fkey";
ALTER TABLE ONLY public."Ratings" DROP CONSTRAINT "Ratings_ratingTypeId_fkey";
ALTER TABLE ONLY public."Ratings" DROP CONSTRAINT "Ratings_eventDetailId_fkey";
ALTER TABLE ONLY public."Posts" DROP CONSTRAINT "Posts_postTypeId_fkey";
ALTER TABLE ONLY public."Posts" DROP CONSTRAINT "Posts_organizationId_fkey";
ALTER TABLE ONLY public."Posts" DROP CONSTRAINT "Posts_eventDetailId_fkey";
ALTER TABLE ONLY public."Posts" DROP CONSTRAINT "Posts_categoryId_fkey";
ALTER TABLE ONLY public."Pharmacies" DROP CONSTRAINT "Pharmacies_webId_fkey";
ALTER TABLE ONLY public."PersonTimetables" DROP CONSTRAINT "PersonTimetables_timetableId_fkey";
ALTER TABLE ONLY public."PersonTimetables" DROP CONSTRAINT "PersonTimetables_personId_fkey";
ALTER TABLE ONLY public."People" DROP CONSTRAINT "People_userId_fkey";
ALTER TABLE ONLY public."People" DROP CONSTRAINT "People_specialityId_fkey";
ALTER TABLE ONLY public."Patients" DROP CONSTRAINT "Patients_userId_fkey";
ALTER TABLE ONLY public."Notifications" DROP CONSTRAINT "Notifications_userId_fkey";
ALTER TABLE ONLY public."Notifications" DROP CONSTRAINT "Notifications_typeId_fkey";
ALTER TABLE ONLY public."Messages" DROP CONSTRAINT "Messages_userId_fkey";
ALTER TABLE ONLY public."Messages" DROP CONSTRAINT "Messages_typeId_fkey";
ALTER TABLE ONLY public."Messages" DROP CONSTRAINT "Messages_organizationId_fkey";
ALTER TABLE ONLY public."Messages" DROP CONSTRAINT "Messages_cancelId_fkey";
ALTER TABLE ONLY public."MedicalRecords" DROP CONSTRAINT "MedicalRecords_patientId_fkey";
ALTER TABLE ONLY public."MedicalCenters" DROP CONSTRAINT "MedicalCenters_webId_fkey";
ALTER TABLE ONLY public."LegalGuardians" DROP CONSTRAINT "LegalGuardians_patientId_fkey";
ALTER TABLE ONLY public."IllnessDiagnoses" DROP CONSTRAINT "IllnessDiagnoses_illnessId_fkey";
ALTER TABLE ONLY public."IllnessDiagnoses" DROP CONSTRAINT "IllnessDiagnoses_appointmentHistoryId_fkey";
ALTER TABLE ONLY public."Guests" DROP CONSTRAINT "Guests_eventDetailId_fkey";
ALTER TABLE ONLY public."GlucoseMeasurements" DROP CONSTRAINT "GlucoseMeasurements_patientId_fkey";
ALTER TABLE ONLY public."GlucoseMeasurements" DROP CONSTRAINT "GlucoseMeasurements_measurementTypeId_fkey";
ALTER TABLE ONLY public."GeneralInformations" DROP CONSTRAINT "GeneralInformations_webId_fkey";
ALTER TABLE ONLY public."Faqs" DROP CONSTRAINT "Faqs_organizationId_fkey";
ALTER TABLE ONLY public."Events" DROP CONSTRAINT "Events_eventTypeId_fkey";
ALTER TABLE ONLY public."EventResultParameters" DROP CONSTRAINT "EventResultParameters_resultParameterId_fkey";
ALTER TABLE ONLY public."EventResultParameters" DROP CONSTRAINT "EventResultParameters_eventDetailId_fkey";
ALTER TABLE ONLY public."EventParticipants" DROP CONSTRAINT "EventParticipants_userId_fkey";
ALTER TABLE ONLY public."EventParticipants" DROP CONSTRAINT "EventParticipants_participantTypeId_fkey";
ALTER TABLE ONLY public."EventParticipants" DROP CONSTRAINT "EventParticipants_eventDetailId_fkey";
ALTER TABLE ONLY public."EventDetails" DROP CONSTRAINT "EventDetails_eventId_fkey";
ALTER TABLE ONLY public."EventDetailPatients" DROP CONSTRAINT "EventDetailPatients_patientId_fkey";
ALTER TABLE ONLY public."EventDetailPatients" DROP CONSTRAINT "EventDetailPatients_eventDetailId_fkey";
ALTER TABLE ONLY public."EventContingencies" DROP CONSTRAINT "EventContingencies_eventDetailId_fkey";
ALTER TABLE ONLY public."EventContingencies" DROP CONSTRAINT "EventContingencies_eventCancelId_fkey";
ALTER TABLE ONLY public."EconomicStatuses" DROP CONSTRAINT "EconomicStatuses_medicalRecordId_fkey";
ALTER TABLE ONLY public."Donatives" DROP CONSTRAINT "Donatives_typeId_fkey";
ALTER TABLE ONLY public."Donations" DROP CONSTRAINT "Donations_donativeId_fkey";
ALTER TABLE ONLY public."Comments" DROP CONSTRAINT "Comments_userId_fkey";
ALTER TABLE ONLY public."Comments" DROP CONSTRAINT "Comments_postId_fkey";
ALTER TABLE ONLY public."Bitacoras" DROP CONSTRAINT "Bitacoras_userId_fkey";
ALTER TABLE ONLY public."AssignedDonatives" DROP CONSTRAINT "AssignedDonatives_patientId_fkey";
ALTER TABLE ONLY public."AssignedDonatives" DROP CONSTRAINT "AssignedDonatives_donativeId_fkey";
ALTER TABLE ONLY public."Appointments" DROP CONSTRAINT "Appointments_typeId_fkey";
ALTER TABLE ONLY public."Appointments" DROP CONSTRAINT "Appointments_timetableId_fkey";
ALTER TABLE ONLY public."Appointments" DROP CONSTRAINT "Appointments_serviceId_fkey";
ALTER TABLE ONLY public."Appointments" DROP CONSTRAINT "Appointments_prePatientId_fkey";
ALTER TABLE ONLY public."Appointments" DROP CONSTRAINT "Appointments_personId_fkey";
ALTER TABLE ONLY public."Appointments" DROP CONSTRAINT "Appointments_patientId_fkey";
ALTER TABLE ONLY public."AppointmentHistories" DROP CONSTRAINT "AppointmentHistories_medicalRecordId_fkey";
ALTER TABLE ONLY public."AppointmentHistories" DROP CONSTRAINT "AppointmentHistories_appointmentId_fkey";
ALTER TABLE ONLY public."WebContents" DROP CONSTRAINT "WebContents_pkey";
ALTER TABLE ONLY public."Users" DROP CONSTRAINT "Users_username_key";
ALTER TABLE ONLY public."Users" DROP CONSTRAINT "Users_pkey";
ALTER TABLE ONLY public."Users" DROP CONSTRAINT "Users_email_key";
ALTER TABLE ONLY public."Timetables" DROP CONSTRAINT "Timetables_pkey";
ALTER TABLE ONLY public."SystemFunctions" DROP CONSTRAINT "SystemFunctions_pkey";
ALTER TABLE ONLY public."SystemFunctionRoles" DROP CONSTRAINT "SystemFunctionRoles_pkey";
ALTER TABLE ONLY public."Specialities" DROP CONSTRAINT "Specialities_pkey";
ALTER TABLE ONLY public."Specialities" DROP CONSTRAINT "Specialities_name_key";
ALTER TABLE ONLY public."Services" DROP CONSTRAINT "Services_pkey";
ALTER TABLE ONLY public."Services" DROP CONSTRAINT "Services_name_key";
ALTER TABLE ONLY public."ServiceTypes" DROP CONSTRAINT "ServiceTypes_pkey";
ALTER TABLE ONLY public."ServiceTypes" DROP CONSTRAINT "ServiceTypes_name_key";
ALTER TABLE ONLY public."ServiceRatingTypes" DROP CONSTRAINT "ServiceRatingTypes_pkey";
ALTER TABLE ONLY public."SequelizeMeta" DROP CONSTRAINT "SequelizeMeta_pkey";
ALTER TABLE ONLY public."Roles" DROP CONSTRAINT "Roles_pkey";
ALTER TABLE ONLY public."Roles" DROP CONSTRAINT "Roles_name_key";
ALTER TABLE ONLY public."RiskFactors" DROP CONSTRAINT "RiskFactors_pkey";
ALTER TABLE ONLY public."RiskFactors" DROP CONSTRAINT "RiskFactors_name_key";
ALTER TABLE ONLY public."RiskFactorDiagnoses" DROP CONSTRAINT "RiskFactorDiagnoses_pkey";
ALTER TABLE ONLY public."ResultParameters" DROP CONSTRAINT "ResultParameters_pkey";
ALTER TABLE ONLY public."ResultParameters" DROP CONSTRAINT "ResultParameters_name_key";
ALTER TABLE ONLY public."Resources" DROP CONSTRAINT "Resources_pkey";
ALTER TABLE ONLY public."Resources" DROP CONSTRAINT "Resources_name_key";
ALTER TABLE ONLY public."Requests" DROP CONSTRAINT "Requests_pkey";
ALTER TABLE ONLY public."RequestTypes" DROP CONSTRAINT "RequestTypes_pkey";
ALTER TABLE ONLY public."RequestTypes" DROP CONSTRAINT "RequestTypes_name_key";
ALTER TABLE ONLY public."Ratings" DROP CONSTRAINT "Ratings_pkey";
ALTER TABLE ONLY public."RatingTypes" DROP CONSTRAINT "RatingTypes_pkey";
ALTER TABLE ONLY public."RatingTypes" DROP CONSTRAINT "RatingTypes_name_key";
ALTER TABLE ONLY public."PrePatients" DROP CONSTRAINT "PrePatients_pkey";
ALTER TABLE ONLY public."Posts" DROP CONSTRAINT "Posts_pkey";
ALTER TABLE ONLY public."PostTypes" DROP CONSTRAINT "PostTypes_pkey";
ALTER TABLE ONLY public."PostTypes" DROP CONSTRAINT "PostTypes_name_key";
ALTER TABLE ONLY public."PostCategories" DROP CONSTRAINT "PostCategories_pkey";
ALTER TABLE ONLY public."PostCategories" DROP CONSTRAINT "PostCategories_name_key";
ALTER TABLE ONLY public."Pharmacies" DROP CONSTRAINT "Pharmacies_pkey";
ALTER TABLE ONLY public."Pharmacies" DROP CONSTRAINT "Pharmacies_name_key";
ALTER TABLE ONLY public."PersonTypes" DROP CONSTRAINT "PersonTypes_pkey";
ALTER TABLE ONLY public."PersonTypes" DROP CONSTRAINT "PersonTypes_name_key";
ALTER TABLE ONLY public."PersonTimetables" DROP CONSTRAINT "PersonTimetables_pkey";
ALTER TABLE ONLY public."People" DROP CONSTRAINT "People_rif_key";
ALTER TABLE ONLY public."People" DROP CONSTRAINT "People_pkey";
ALTER TABLE ONLY public."People" DROP CONSTRAINT "People_cedula_key";
ALTER TABLE ONLY public."Patients" DROP CONSTRAINT "Patients_rif_key";
ALTER TABLE ONLY public."Patients" DROP CONSTRAINT "Patients_pkey";
ALTER TABLE ONLY public."Patients" DROP CONSTRAINT "Patients_cedula_key";
ALTER TABLE ONLY public."ParticipantTypes" DROP CONSTRAINT "ParticipantTypes_pkey";
ALTER TABLE ONLY public."ParticipantTypes" DROP CONSTRAINT "ParticipantTypes_name_key";
ALTER TABLE ONLY public."Organizations" DROP CONSTRAINT "Organizations_pkey";
ALTER TABLE ONLY public."Organizations" DROP CONSTRAINT "Organizations_name_key";
ALTER TABLE ONLY public."Notifications" DROP CONSTRAINT "Notifications_pkey";
ALTER TABLE ONLY public."NotificationTypes" DROP CONSTRAINT "NotificationTypes_pkey";
ALTER TABLE ONLY public."NotificationTypes" DROP CONSTRAINT "NotificationTypes_name_key";
ALTER TABLE ONLY public."Messages" DROP CONSTRAINT "Messages_pkey";
ALTER TABLE ONLY public."MessageTypes" DROP CONSTRAINT "MessageTypes_pkey";
ALTER TABLE ONLY public."MessageTypes" DROP CONSTRAINT "MessageTypes_name_key";
ALTER TABLE ONLY public."MessageCancelTypes" DROP CONSTRAINT "MessageCancelTypes_pkey";
ALTER TABLE ONLY public."MessageCancelTypes" DROP CONSTRAINT "MessageCancelTypes_name_key";
ALTER TABLE ONLY public."MedicalRecords" DROP CONSTRAINT "MedicalRecords_pkey";
ALTER TABLE ONLY public."MedicalRecords" DROP CONSTRAINT "MedicalRecords_patientId_key";
ALTER TABLE ONLY public."MedicalCenters" DROP CONSTRAINT "MedicalCenters_pkey";
ALTER TABLE ONLY public."MedicalCenters" DROP CONSTRAINT "MedicalCenters_name_key";
ALTER TABLE ONLY public."MeasurementTypes" DROP CONSTRAINT "MeasurementTypes_pkey";
ALTER TABLE ONLY public."MeasurementTypes" DROP CONSTRAINT "MeasurementTypes_name_key";
ALTER TABLE ONLY public."LegalGuardians" DROP CONSTRAINT "LegalGuardians_pkey";
ALTER TABLE ONLY public."Illnesses" DROP CONSTRAINT "Illnesses_pkey";
ALTER TABLE ONLY public."Illnesses" DROP CONSTRAINT "Illnesses_name_key";
ALTER TABLE ONLY public."IllnessDiagnoses" DROP CONSTRAINT "IllnessDiagnoses_pkey";
ALTER TABLE ONLY public."Guests" DROP CONSTRAINT "Guests_pkey";
ALTER TABLE ONLY public."GlucoseMeasurements" DROP CONSTRAINT "GlucoseMeasurements_pkey";
ALTER TABLE ONLY public."GeneralInformations" DROP CONSTRAINT "GeneralInformations_pkey";
ALTER TABLE ONLY public."Faqs" DROP CONSTRAINT "Faqs_question_key";
ALTER TABLE ONLY public."Faqs" DROP CONSTRAINT "Faqs_pkey";
ALTER TABLE ONLY public."Faqs" DROP CONSTRAINT "Faqs_answer_key";
ALTER TABLE ONLY public."Events" DROP CONSTRAINT "Events_pkey";
ALTER TABLE ONLY public."Events" DROP CONSTRAINT "Events_name_key";
ALTER TABLE ONLY public."EventTypes" DROP CONSTRAINT "EventTypes_pkey";
ALTER TABLE ONLY public."EventTypes" DROP CONSTRAINT "EventTypes_name_key";
ALTER TABLE ONLY public."EventResultParameters" DROP CONSTRAINT "EventResultParameters_pkey";
ALTER TABLE ONLY public."EventResources" DROP CONSTRAINT "EventResources_pkey";
ALTER TABLE ONLY public."EventRatingTypes" DROP CONSTRAINT "EventRatingTypes_pkey";
ALTER TABLE ONLY public."EventParticipants" DROP CONSTRAINT "EventParticipants_pkey";
ALTER TABLE ONLY public."EventDetails" DROP CONSTRAINT "EventDetails_pkey";
ALTER TABLE ONLY public."EventDetailPatients" DROP CONSTRAINT "EventDetailPatients_pkey";
ALTER TABLE ONLY public."EventContingencies" DROP CONSTRAINT "EventContingencies_pkey";
ALTER TABLE ONLY public."EventCancelTypes" DROP CONSTRAINT "EventCancelTypes_pkey";
ALTER TABLE ONLY public."EventCancelTypes" DROP CONSTRAINT "EventCancelTypes_name_key";
ALTER TABLE ONLY public."EconomicStatuses" DROP CONSTRAINT "EconomicStatuses_pkey";
ALTER TABLE ONLY public."EconomicStatuses" DROP CONSTRAINT "EconomicStatuses_medicalRecordId_key";
ALTER TABLE ONLY public."Donatives" DROP CONSTRAINT "Donatives_pkey";
ALTER TABLE ONLY public."Donatives" DROP CONSTRAINT "Donatives_name_key";
ALTER TABLE ONLY public."Donations" DROP CONSTRAINT "Donations_pkey";
ALTER TABLE ONLY public."DonationTypes" DROP CONSTRAINT "DonationTypes_pkey";
ALTER TABLE ONLY public."DonationTypes" DROP CONSTRAINT "DonationTypes_name_key";
ALTER TABLE ONLY public."DiabetesTypes" DROP CONSTRAINT "DiabetesTypes_pkey";
ALTER TABLE ONLY public."DiabetesTypes" DROP CONSTRAINT "DiabetesTypes_name_key";
ALTER TABLE ONLY public."Comments" DROP CONSTRAINT "Comments_pkey";
ALTER TABLE ONLY public."Bitacoras" DROP CONSTRAINT "Bitacoras_pkey";
ALTER TABLE ONLY public."AssignedDonatives" DROP CONSTRAINT "AssignedDonatives_pkey";
ALTER TABLE ONLY public."Appointments" DROP CONSTRAINT "Appointments_pkey";
ALTER TABLE ONLY public."AppointmentTypes" DROP CONSTRAINT "AppointmentTypes_pkey";
ALTER TABLE ONLY public."AppointmentTypes" DROP CONSTRAINT "AppointmentTypes_name_key";
ALTER TABLE ONLY public."AppointmentHistories" DROP CONSTRAINT "AppointmentHistories_pkey";
ALTER TABLE ONLY public."AppointmentHistories" DROP CONSTRAINT "AppointmentHistories_appointmentId_key";
ALTER TABLE ONLY public."AppointmentCancelTypes" DROP CONSTRAINT "AppointmentCancelTypes_pkey";
ALTER TABLE ONLY public."AppointmentCancelTypes" DROP CONSTRAINT "AppointmentCancelTypes_name_key";
ALTER TABLE public."WebContents" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Users" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Timetables" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."SystemFunctions" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."SystemFunctionRoles" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Specialities" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Services" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."ServiceTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."ServiceRatingTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Roles" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."RiskFactors" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."RiskFactorDiagnoses" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."ResultParameters" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Resources" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Requests" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."RequestTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Ratings" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."RatingTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."PrePatients" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Posts" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."PostTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."PostCategories" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Pharmacies" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."PersonTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."PersonTimetables" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."People" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Patients" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."ParticipantTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Organizations" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Notifications" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."NotificationTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Messages" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."MessageTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."MessageCancelTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."MedicalRecords" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."MedicalCenters" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."MeasurementTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."LegalGuardians" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Illnesses" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."IllnessDiagnoses" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Guests" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."GlucoseMeasurements" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."GeneralInformations" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Faqs" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Events" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EventTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EventResultParameters" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EventResources" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EventRatingTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EventParticipants" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EventDetails" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EventDetailPatients" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EventContingencies" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EventCancelTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."EconomicStatuses" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Donatives" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Donations" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."DonationTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."DiabetesTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Comments" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Bitacoras" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."AssignedDonatives" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."Appointments" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."AppointmentTypes" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."AppointmentHistories" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."AppointmentCancelTypes" ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public."WebContents_id_seq";
DROP TABLE public."WebContents";
DROP SEQUENCE public."Users_id_seq";
DROP TABLE public."Users";
DROP SEQUENCE public."Timetables_id_seq";
DROP TABLE public."Timetables";
DROP SEQUENCE public."SystemFunctions_id_seq";
DROP TABLE public."SystemFunctions";
DROP SEQUENCE public."SystemFunctionRoles_id_seq";
DROP TABLE public."SystemFunctionRoles";
DROP SEQUENCE public."Specialities_id_seq";
DROP TABLE public."Specialities";
DROP SEQUENCE public."Services_id_seq";
DROP TABLE public."Services";
DROP SEQUENCE public."ServiceTypes_id_seq";
DROP TABLE public."ServiceTypes";
DROP SEQUENCE public."ServiceRatingTypes_id_seq";
DROP TABLE public."ServiceRatingTypes";
DROP TABLE public."SequelizeMeta";
DROP SEQUENCE public."Roles_id_seq";
DROP TABLE public."Roles";
DROP SEQUENCE public."RiskFactors_id_seq";
DROP TABLE public."RiskFactors";
DROP SEQUENCE public."RiskFactorDiagnoses_id_seq";
DROP TABLE public."RiskFactorDiagnoses";
DROP SEQUENCE public."ResultParameters_id_seq";
DROP TABLE public."ResultParameters";
DROP SEQUENCE public."Resources_id_seq";
DROP TABLE public."Resources";
DROP SEQUENCE public."Requests_id_seq";
DROP TABLE public."Requests";
DROP SEQUENCE public."RequestTypes_id_seq";
DROP TABLE public."RequestTypes";
DROP SEQUENCE public."Ratings_id_seq";
DROP TABLE public."Ratings";
DROP SEQUENCE public."RatingTypes_id_seq";
DROP TABLE public."RatingTypes";
DROP SEQUENCE public."PrePatients_id_seq";
DROP TABLE public."PrePatients";
DROP SEQUENCE public."Posts_id_seq";
DROP TABLE public."Posts";
DROP SEQUENCE public."PostTypes_id_seq";
DROP TABLE public."PostTypes";
DROP SEQUENCE public."PostCategories_id_seq";
DROP TABLE public."PostCategories";
DROP SEQUENCE public."Pharmacies_id_seq";
DROP TABLE public."Pharmacies";
DROP SEQUENCE public."PersonTypes_id_seq";
DROP TABLE public."PersonTypes";
DROP SEQUENCE public."PersonTimetables_id_seq";
DROP TABLE public."PersonTimetables";
DROP SEQUENCE public."People_id_seq";
DROP TABLE public."People";
DROP SEQUENCE public."Patients_id_seq";
DROP TABLE public."Patients";
DROP SEQUENCE public."ParticipantTypes_id_seq";
DROP TABLE public."ParticipantTypes";
DROP SEQUENCE public."Organizations_id_seq";
DROP TABLE public."Organizations";
DROP SEQUENCE public."Notifications_id_seq";
DROP TABLE public."Notifications";
DROP SEQUENCE public."NotificationTypes_id_seq";
DROP TABLE public."NotificationTypes";
DROP SEQUENCE public."Messages_id_seq";
DROP TABLE public."Messages";
DROP SEQUENCE public."MessageTypes_id_seq";
DROP TABLE public."MessageTypes";
DROP SEQUENCE public."MessageCancelTypes_id_seq";
DROP TABLE public."MessageCancelTypes";
DROP SEQUENCE public."MedicalRecords_id_seq";
DROP TABLE public."MedicalRecords";
DROP SEQUENCE public."MedicalCenters_id_seq";
DROP TABLE public."MedicalCenters";
DROP SEQUENCE public."MeasurementTypes_id_seq";
DROP TABLE public."MeasurementTypes";
DROP SEQUENCE public."LegalGuardians_id_seq";
DROP TABLE public."LegalGuardians";
DROP SEQUENCE public."Illnesses_id_seq";
DROP TABLE public."Illnesses";
DROP SEQUENCE public."IllnessDiagnoses_id_seq";
DROP TABLE public."IllnessDiagnoses";
DROP SEQUENCE public."Guests_id_seq";
DROP TABLE public."Guests";
DROP SEQUENCE public."GlucoseMeasurements_id_seq";
DROP TABLE public."GlucoseMeasurements";
DROP SEQUENCE public."GeneralInformations_id_seq";
DROP TABLE public."GeneralInformations";
DROP SEQUENCE public."Faqs_id_seq";
DROP TABLE public."Faqs";
DROP SEQUENCE public."Events_id_seq";
DROP TABLE public."Events";
DROP SEQUENCE public."EventTypes_id_seq";
DROP TABLE public."EventTypes";
DROP SEQUENCE public."EventResultParameters_id_seq";
DROP TABLE public."EventResultParameters";
DROP SEQUENCE public."EventResources_id_seq";
DROP TABLE public."EventResources";
DROP SEQUENCE public."EventRatingTypes_id_seq";
DROP TABLE public."EventRatingTypes";
DROP SEQUENCE public."EventParticipants_id_seq";
DROP TABLE public."EventParticipants";
DROP SEQUENCE public."EventDetails_id_seq";
DROP TABLE public."EventDetails";
DROP SEQUENCE public."EventDetailPatients_id_seq";
DROP TABLE public."EventDetailPatients";
DROP SEQUENCE public."EventContingencies_id_seq";
DROP TABLE public."EventContingencies";
DROP SEQUENCE public."EventCancelTypes_id_seq";
DROP TABLE public."EventCancelTypes";
DROP SEQUENCE public."EconomicStatuses_id_seq";
DROP TABLE public."EconomicStatuses";
DROP SEQUENCE public."Donatives_id_seq";
DROP TABLE public."Donatives";
DROP SEQUENCE public."Donations_id_seq";
DROP TABLE public."Donations";
DROP SEQUENCE public."DonationTypes_id_seq";
DROP TABLE public."DonationTypes";
DROP SEQUENCE public."DiabetesTypes_id_seq";
DROP TABLE public."DiabetesTypes";
DROP SEQUENCE public."Comments_id_seq";
DROP TABLE public."Comments";
DROP SEQUENCE public."Bitacoras_id_seq";
DROP TABLE public."Bitacoras";
DROP SEQUENCE public."AssignedDonatives_id_seq";
DROP TABLE public."AssignedDonatives";
DROP SEQUENCE public."Appointments_id_seq";
DROP TABLE public."Appointments";
DROP SEQUENCE public."AppointmentTypes_id_seq";
DROP TABLE public."AppointmentTypes";
DROP SEQUENCE public."AppointmentHistories_id_seq";
DROP TABLE public."AppointmentHistories";
DROP SEQUENCE public."AppointmentCancelTypes_id_seq";
DROP TABLE public."AppointmentCancelTypes";
DROP TYPE public."enum_Timetables_day";
DROP TYPE public."enum_RatingTypes_scale";
DROP TYPE public."enum_RatingTypes_entity";
DROP TYPE public."enum_PrePatients_gender";
DROP TYPE public."enum_People_gender";
DROP TYPE public."enum_Patients_maritalStatus";
DROP TYPE public."enum_Patients_gender";
DROP TYPE public."enum_LegalGuardians_gender";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: enum_LegalGuardians_gender; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_LegalGuardians_gender" AS ENUM (
    'masculino',
    'femenino'
);


ALTER TYPE public."enum_LegalGuardians_gender" OWNER TO postgres;

--
-- Name: enum_Patients_gender; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Patients_gender" AS ENUM (
    'masculino',
    'femenino'
);


ALTER TYPE public."enum_Patients_gender" OWNER TO postgres;

--
-- Name: enum_Patients_maritalStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Patients_maritalStatus" AS ENUM (
    'soltero',
    'casado',
    'viudo'
);


ALTER TYPE public."enum_Patients_maritalStatus" OWNER TO postgres;

--
-- Name: enum_People_gender; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_People_gender" AS ENUM (
    'masculino',
    'femenino'
);


ALTER TYPE public."enum_People_gender" OWNER TO postgres;

--
-- Name: enum_PrePatients_gender; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_PrePatients_gender" AS ENUM (
    'masculino',
    'femenino'
);


ALTER TYPE public."enum_PrePatients_gender" OWNER TO postgres;

--
-- Name: enum_RatingTypes_entity; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_RatingTypes_entity" AS ENUM (
    'citas',
    'actividades'
);


ALTER TYPE public."enum_RatingTypes_entity" OWNER TO postgres;

--
-- Name: enum_RatingTypes_scale; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_RatingTypes_scale" AS ENUM (
    'estrellas',
    'respuestas'
);


ALTER TYPE public."enum_RatingTypes_scale" OWNER TO postgres;

--
-- Name: enum_Timetables_day; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Timetables_day" AS ENUM (
    'Lunes',
    'Martes',
    'Miércoles',
    'Jueves',
    'Viernes',
    'Sábado',
    'Domingo'
);


ALTER TYPE public."enum_Timetables_day" OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: AppointmentCancelTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppointmentCancelTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."AppointmentCancelTypes" OWNER TO postgres;

--
-- Name: AppointmentCancelTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppointmentCancelTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AppointmentCancelTypes_id_seq" OWNER TO postgres;

--
-- Name: AppointmentCancelTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppointmentCancelTypes_id_seq" OWNED BY public."AppointmentCancelTypes".id;


--
-- Name: AppointmentHistories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppointmentHistories" (
    id integer NOT NULL,
    "appointmentId" integer NOT NULL,
    "medicalRecordId" integer NOT NULL,
    "glucoseLevel" integer NOT NULL,
    height real NOT NULL,
    weight real NOT NULL,
    "bloodPressureUp" integer NOT NULL,
    "bloodPressureDown" integer NOT NULL,
    "physicalExamination" text NOT NULL,
    treatments text NOT NULL,
    "medicalConditions" text NOT NULL,
    description text NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."AppointmentHistories" OWNER TO postgres;

--
-- Name: AppointmentHistories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppointmentHistories_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AppointmentHistories_id_seq" OWNER TO postgres;

--
-- Name: AppointmentHistories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppointmentHistories_id_seq" OWNED BY public."AppointmentHistories".id;


--
-- Name: AppointmentTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AppointmentTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."AppointmentTypes" OWNER TO postgres;

--
-- Name: AppointmentTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AppointmentTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AppointmentTypes_id_seq" OWNER TO postgres;

--
-- Name: AppointmentTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AppointmentTypes_id_seq" OWNED BY public."AppointmentTypes".id;


--
-- Name: Appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Appointments" (
    id integer NOT NULL,
    "patientId" integer,
    "prePatientId" integer,
    "typeId" integer NOT NULL,
    "serviceId" integer NOT NULL,
    "personId" integer NOT NULL,
    date date NOT NULL,
    description text NOT NULL,
    status boolean NOT NULL,
    "statusAppointment" character varying(255) NOT NULL,
    "dayNumber" integer NOT NULL,
    "timetableId" integer,
    qualified boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone,
    "cancelId" integer
);


ALTER TABLE public."Appointments" OWNER TO postgres;

--
-- Name: Appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Appointments_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Appointments_id_seq" OWNER TO postgres;

--
-- Name: Appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Appointments_id_seq" OWNED BY public."Appointments".id;


--
-- Name: AssignedDonatives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AssignedDonatives" (
    id integer NOT NULL,
    "patientId" integer NOT NULL,
    "donativeId" integer NOT NULL,
    "assignationDate" date NOT NULL,
    description text,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."AssignedDonatives" OWNER TO postgres;

--
-- Name: AssignedDonatives_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AssignedDonatives_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AssignedDonatives_id_seq" OWNER TO postgres;

--
-- Name: AssignedDonatives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AssignedDonatives_id_seq" OWNED BY public."AssignedDonatives".id;


--
-- Name: Bitacoras; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Bitacoras" (
    id integer NOT NULL,
    "modelName" character varying(255) NOT NULL,
    "recordId" integer NOT NULL,
    "recordName" character varying(255) NOT NULL,
    operation character varying(255) NOT NULL,
    "userId" integer,
    date timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Bitacoras" OWNER TO postgres;

--
-- Name: Bitacoras_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Bitacoras_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Bitacoras_id_seq" OWNER TO postgres;

--
-- Name: Bitacoras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Bitacoras_id_seq" OWNED BY public."Bitacoras".id;


--
-- Name: Comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Comments" (
    id integer NOT NULL,
    message text NOT NULL,
    status boolean,
    "userId" integer NOT NULL,
    "postId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Comments" OWNER TO postgres;

--
-- Name: Comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Comments_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Comments_id_seq" OWNER TO postgres;

--
-- Name: Comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Comments_id_seq" OWNED BY public."Comments".id;


--
-- Name: DiabetesTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DiabetesTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."DiabetesTypes" OWNER TO postgres;

--
-- Name: DiabetesTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DiabetesTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DiabetesTypes_id_seq" OWNER TO postgres;

--
-- Name: DiabetesTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DiabetesTypes_id_seq" OWNED BY public."DiabetesTypes".id;


--
-- Name: DonationTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DonationTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    status boolean DEFAULT true NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."DonationTypes" OWNER TO postgres;

--
-- Name: DonationTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DonationTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DonationTypes_id_seq" OWNER TO postgres;

--
-- Name: DonationTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DonationTypes_id_seq" OWNED BY public."DonationTypes".id;


--
-- Name: Donations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Donations" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "lastName" character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    description text NOT NULL,
    status boolean DEFAULT false NOT NULL,
    "donativeId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Donations" OWNER TO postgres;

--
-- Name: Donations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Donations_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Donations_id_seq" OWNER TO postgres;

--
-- Name: Donations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Donations_id_seq" OWNED BY public."Donations".id;


--
-- Name: Donatives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Donatives" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    status boolean DEFAULT true NOT NULL,
    "typeId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Donatives" OWNER TO postgres;

--
-- Name: Donatives_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Donatives_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Donatives_id_seq" OWNER TO postgres;

--
-- Name: Donatives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Donatives_id_seq" OWNED BY public."Donatives".id;


--
-- Name: EconomicStatuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EconomicStatuses" (
    id integer NOT NULL,
    "familyHead" character varying(255),
    housing character varying(255),
    insurance boolean,
    "monthlySalary" double precision,
    "familyMembers" integer,
    other text,
    status boolean NOT NULL,
    "medicalRecordId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EconomicStatuses" OWNER TO postgres;

--
-- Name: EconomicStatuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EconomicStatuses_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EconomicStatuses_id_seq" OWNER TO postgres;

--
-- Name: EconomicStatuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EconomicStatuses_id_seq" OWNED BY public."EconomicStatuses".id;


--
-- Name: EventCancelTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventCancelTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EventCancelTypes" OWNER TO postgres;

--
-- Name: EventCancelTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventCancelTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventCancelTypes_id_seq" OWNER TO postgres;

--
-- Name: EventCancelTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventCancelTypes_id_seq" OWNED BY public."EventCancelTypes".id;


--
-- Name: EventContingencies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventContingencies" (
    id integer NOT NULL,
    "eventDetailId" integer NOT NULL,
    "eventCancelId" integer NOT NULL,
    "initialDate" timestamp with time zone NOT NULL,
    "initialTime" time without time zone NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EventContingencies" OWNER TO postgres;

--
-- Name: EventContingencies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventContingencies_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventContingencies_id_seq" OWNER TO postgres;

--
-- Name: EventContingencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventContingencies_id_seq" OWNED BY public."EventContingencies".id;


--
-- Name: EventDetailPatients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventDetailPatients" (
    id integer NOT NULL,
    "eventDetailId" integer NOT NULL,
    "patientId" integer NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EventDetailPatients" OWNER TO postgres;

--
-- Name: EventDetailPatients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventDetailPatients_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventDetailPatients_id_seq" OWNER TO postgres;

--
-- Name: EventDetailPatients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventDetailPatients_id_seq" OWNED BY public."EventDetailPatients".id;


--
-- Name: EventDetails; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventDetails" (
    id integer NOT NULL,
    "eventId" integer NOT NULL,
    status boolean NOT NULL,
    evaluation boolean,
    "statusDetail" character varying(255),
    name character varying(255) NOT NULL,
    "plannedDate" timestamp with time zone NOT NULL,
    "time" time without time zone NOT NULL,
    "realDate" timestamp with time zone,
    place character varying(255) NOT NULL,
    description text NOT NULL,
    image character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EventDetails" OWNER TO postgres;

--
-- Name: EventDetails_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventDetails_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventDetails_id_seq" OWNER TO postgres;

--
-- Name: EventDetails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventDetails_id_seq" OWNED BY public."EventDetails".id;


--
-- Name: EventParticipants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventParticipants" (
    id integer NOT NULL,
    "eventDetailId" integer NOT NULL,
    "participantTypeId" integer NOT NULL,
    "userId" integer NOT NULL,
    "assistedEvent" boolean,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EventParticipants" OWNER TO postgres;

--
-- Name: EventParticipants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventParticipants_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventParticipants_id_seq" OWNER TO postgres;

--
-- Name: EventParticipants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventParticipants_id_seq" OWNED BY public."EventParticipants".id;


--
-- Name: EventRatingTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventRatingTypes" (
    id integer NOT NULL,
    "ratingTypeId" integer NOT NULL,
    "eventId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EventRatingTypes" OWNER TO postgres;

--
-- Name: EventRatingTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventRatingTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventRatingTypes_id_seq" OWNER TO postgres;

--
-- Name: EventRatingTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventRatingTypes_id_seq" OWNED BY public."EventRatingTypes".id;


--
-- Name: EventResources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventResources" (
    id integer NOT NULL,
    "eventDetailId" integer NOT NULL,
    "resourceId" integer NOT NULL,
    quantity integer NOT NULL,
    description text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EventResources" OWNER TO postgres;

--
-- Name: EventResources_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventResources_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventResources_id_seq" OWNER TO postgres;

--
-- Name: EventResources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventResources_id_seq" OWNED BY public."EventResources".id;


--
-- Name: EventResultParameters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventResultParameters" (
    id integer NOT NULL,
    "eventDetailId" integer NOT NULL,
    "resultParameterId" integer NOT NULL,
    "minValue" integer NOT NULL,
    "maxValue" integer NOT NULL,
    "realValue" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EventResultParameters" OWNER TO postgres;

--
-- Name: EventResultParameters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventResultParameters_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventResultParameters_id_seq" OWNER TO postgres;

--
-- Name: EventResultParameters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventResultParameters_id_seq" OWNED BY public."EventResultParameters".id;


--
-- Name: EventTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."EventTypes" OWNER TO postgres;

--
-- Name: EventTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventTypes_id_seq" OWNER TO postgres;

--
-- Name: EventTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventTypes_id_seq" OWNED BY public."EventTypes".id;


--
-- Name: Events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Events" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    topic character varying(255) NOT NULL,
    description text NOT NULL,
    "eventTypeId" integer NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Events" OWNER TO postgres;

--
-- Name: Events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Events_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Events_id_seq" OWNER TO postgres;

--
-- Name: Events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Events_id_seq" OWNED BY public."Events".id;


--
-- Name: Faqs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Faqs" (
    id integer NOT NULL,
    question character varying(255) NOT NULL,
    answer text NOT NULL,
    status boolean NOT NULL,
    "organizationId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Faqs" OWNER TO postgres;

--
-- Name: Faqs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Faqs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Faqs_id_seq" OWNER TO postgres;

--
-- Name: Faqs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Faqs_id_seq" OWNED BY public."Faqs".id;


--
-- Name: GeneralInformations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GeneralInformations" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    image character varying(255),
    status boolean NOT NULL,
    "webId" integer NOT NULL,
    visibility boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."GeneralInformations" OWNER TO postgres;

--
-- Name: GeneralInformations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GeneralInformations_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."GeneralInformations_id_seq" OWNER TO postgres;

--
-- Name: GeneralInformations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GeneralInformations_id_seq" OWNED BY public."GeneralInformations".id;


--
-- Name: GlucoseMeasurements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GlucoseMeasurements" (
    id integer NOT NULL,
    "measurementTypeId" integer NOT NULL,
    "patientId" integer NOT NULL,
    status boolean NOT NULL,
    result integer NOT NULL,
    "resultDate" timestamp with time zone NOT NULL,
    "createdAt" date NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."GlucoseMeasurements" OWNER TO postgres;

--
-- Name: GlucoseMeasurements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GlucoseMeasurements_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."GlucoseMeasurements_id_seq" OWNER TO postgres;

--
-- Name: GlucoseMeasurements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GlucoseMeasurements_id_seq" OWNED BY public."GlucoseMeasurements".id;


--
-- Name: Guests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Guests" (
    id integer NOT NULL,
    "eventDetailId" integer NOT NULL,
    status boolean NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    occupations text NOT NULL,
    description text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Guests" OWNER TO postgres;

--
-- Name: Guests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Guests_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Guests_id_seq" OWNER TO postgres;

--
-- Name: Guests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Guests_id_seq" OWNED BY public."Guests".id;


--
-- Name: IllnessDiagnoses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."IllnessDiagnoses" (
    id integer NOT NULL,
    status boolean NOT NULL,
    "illnessId" integer NOT NULL,
    "appointmentHistoryId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."IllnessDiagnoses" OWNER TO postgres;

--
-- Name: IllnessDiagnoses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."IllnessDiagnoses_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."IllnessDiagnoses_id_seq" OWNER TO postgres;

--
-- Name: IllnessDiagnoses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."IllnessDiagnoses_id_seq" OWNED BY public."IllnessDiagnoses".id;


--
-- Name: Illnesses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Illnesses" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Illnesses" OWNER TO postgres;

--
-- Name: Illnesses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Illnesses_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Illnesses_id_seq" OWNER TO postgres;

--
-- Name: Illnesses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Illnesses_id_seq" OWNED BY public."Illnesses".id;


--
-- Name: LegalGuardians; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LegalGuardians" (
    id integer NOT NULL,
    "patientId" integer NOT NULL,
    status boolean NOT NULL,
    name character varying(255) NOT NULL,
    surname character varying(255),
    gender public."enum_LegalGuardians_gender" NOT NULL,
    birthdate date NOT NULL,
    relationship character varying(255) NOT NULL,
    "phoneNumber" character varying(255),
    address character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."LegalGuardians" OWNER TO postgres;

--
-- Name: LegalGuardians_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LegalGuardians_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LegalGuardians_id_seq" OWNER TO postgres;

--
-- Name: LegalGuardians_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LegalGuardians_id_seq" OWNED BY public."LegalGuardians".id;


--
-- Name: MeasurementTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MeasurementTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "lowerRank" integer NOT NULL,
    "upperRank" integer NOT NULL,
    "dangerLevel" character varying(255) NOT NULL,
    "upperMessage" character varying(255),
    "downMessage" character varying(255),
    "inRangeMessage" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."MeasurementTypes" OWNER TO postgres;

--
-- Name: MeasurementTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MeasurementTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MeasurementTypes_id_seq" OWNER TO postgres;

--
-- Name: MeasurementTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MeasurementTypes_id_seq" OWNED BY public."MeasurementTypes".id;


--
-- Name: MedicalCenters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MedicalCenters" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    address character varying(255) NOT NULL,
    "addressUrl" character varying(255) NOT NULL,
    "phoneNumber" character varying(255) NOT NULL,
    status boolean NOT NULL,
    "webId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."MedicalCenters" OWNER TO postgres;

--
-- Name: MedicalCenters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MedicalCenters_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MedicalCenters_id_seq" OWNER TO postgres;

--
-- Name: MedicalCenters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MedicalCenters_id_seq" OWNED BY public."MedicalCenters".id;


--
-- Name: MedicalRecords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MedicalRecords" (
    id integer NOT NULL,
    "bloodType" character varying(255) NOT NULL,
    "personalBackground" text NOT NULL,
    "familyBackground" text NOT NULL,
    status boolean NOT NULL,
    "patientId" integer NOT NULL,
    amputated boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone,
    "diabetesId" integer
);


ALTER TABLE public."MedicalRecords" OWNER TO postgres;

--
-- Name: MedicalRecords_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MedicalRecords_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MedicalRecords_id_seq" OWNER TO postgres;

--
-- Name: MedicalRecords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MedicalRecords_id_seq" OWNED BY public."MedicalRecords".id;


--
-- Name: MessageCancelTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MessageCancelTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."MessageCancelTypes" OWNER TO postgres;

--
-- Name: MessageCancelTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MessageCancelTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MessageCancelTypes_id_seq" OWNER TO postgres;

--
-- Name: MessageCancelTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MessageCancelTypes_id_seq" OWNED BY public."MessageCancelTypes".id;


--
-- Name: MessageTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MessageTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."MessageTypes" OWNER TO postgres;

--
-- Name: MessageTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MessageTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MessageTypes_id_seq" OWNER TO postgres;

--
-- Name: MessageTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MessageTypes_id_seq" OWNED BY public."MessageTypes".id;


--
-- Name: Messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Messages" (
    id integer NOT NULL,
    "senderName" character varying(255),
    "senderEmail" character varying(255) NOT NULL,
    subject character varying(255),
    "messageContent" text NOT NULL,
    "phoneNumber" character varying(255),
    status boolean NOT NULL,
    "organizationId" integer,
    "typeId" integer NOT NULL,
    "userId" integer,
    "cancelId" integer,
    canceled boolean,
    "attentionDate" timestamp with time zone,
    response text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Messages" OWNER TO postgres;

--
-- Name: Messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Messages_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Messages_id_seq" OWNER TO postgres;

--
-- Name: Messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Messages_id_seq" OWNED BY public."Messages".id;


--
-- Name: NotificationTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NotificationTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."NotificationTypes" OWNER TO postgres;

--
-- Name: NotificationTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."NotificationTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."NotificationTypes_id_seq" OWNER TO postgres;

--
-- Name: NotificationTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."NotificationTypes_id_seq" OWNED BY public."NotificationTypes".id;


--
-- Name: Notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notifications" (
    id integer NOT NULL,
    "typeId" integer NOT NULL,
    "userId" integer NOT NULL,
    "modelId" integer,
    model character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Notifications" OWNER TO postgres;

--
-- Name: Notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Notifications_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Notifications_id_seq" OWNER TO postgres;

--
-- Name: Notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Notifications_id_seq" OWNED BY public."Notifications".id;


--
-- Name: Organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Organizations" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    status boolean NOT NULL,
    address text NOT NULL,
    "addressUrl" character varying(255) NOT NULL,
    mission text NOT NULL,
    vission text NOT NULL,
    "values" text NOT NULL,
    objective text NOT NULL,
    "apkUrl" character varying(255),
    apk character varying(255),
    image character varying(255),
    phone character varying(255) NOT NULL,
    "phoneTwo" character varying(255),
    email character varying(255) NOT NULL,
    rif character varying(255) NOT NULL,
    history text NOT NULL,
    "colorPrimary" character varying(255),
    "colorSecondary" character varying(255),
    "facebookUsername" character varying(255),
    "instagramUsername" character varying(255),
    "twitterUsername" character varying(255),
    "linkedinUsername" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Organizations" OWNER TO postgres;

--
-- Name: Organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Organizations_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Organizations_id_seq" OWNER TO postgres;

--
-- Name: Organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Organizations_id_seq" OWNED BY public."Organizations".id;


--
-- Name: ParticipantTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ParticipantTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."ParticipantTypes" OWNER TO postgres;

--
-- Name: ParticipantTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ParticipantTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ParticipantTypes_id_seq" OWNER TO postgres;

--
-- Name: ParticipantTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ParticipantTypes_id_seq" OWNED BY public."ParticipantTypes".id;


--
-- Name: Patients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Patients" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    surname character varying(255) NOT NULL,
    gender public."enum_Patients_gender" NOT NULL,
    birthdate date NOT NULL,
    "phoneNumber" character varying(255) NOT NULL,
    "maritalStatus" public."enum_Patients_maritalStatus" NOT NULL,
    address character varying(255) NOT NULL,
    cedula character varying(255) NOT NULL,
    rif character varying(255),
    "userId" integer NOT NULL,
    status boolean NOT NULL,
    transaction integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Patients" OWNER TO postgres;

--
-- Name: Patients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Patients_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Patients_id_seq" OWNER TO postgres;

--
-- Name: Patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Patients_id_seq" OWNED BY public."Patients".id;


--
-- Name: People; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."People" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    surname character varying(255) NOT NULL,
    gender public."enum_People_gender" NOT NULL,
    birthdate date NOT NULL,
    "phoneNumber" character varying(255) NOT NULL,
    address character varying(255) NOT NULL,
    cedula character varying(255) NOT NULL,
    rif character varying(255),
    description character varying(255),
    "userId" integer NOT NULL,
    "specialityId" integer NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."People" OWNER TO postgres;

--
-- Name: People_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."People_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."People_id_seq" OWNER TO postgres;

--
-- Name: People_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."People_id_seq" OWNED BY public."People".id;


--
-- Name: PersonTimetables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PersonTimetables" (
    id integer NOT NULL,
    status boolean NOT NULL,
    "personId" integer NOT NULL,
    "timetableId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."PersonTimetables" OWNER TO postgres;

--
-- Name: PersonTimetables_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PersonTimetables_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PersonTimetables_id_seq" OWNER TO postgres;

--
-- Name: PersonTimetables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PersonTimetables_id_seq" OWNED BY public."PersonTimetables".id;


--
-- Name: PersonTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PersonTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."PersonTypes" OWNER TO postgres;

--
-- Name: PersonTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PersonTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PersonTypes_id_seq" OWNER TO postgres;

--
-- Name: PersonTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PersonTypes_id_seq" OWNED BY public."PersonTypes".id;


--
-- Name: Pharmacies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Pharmacies" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    address character varying(255) NOT NULL,
    "addressUrl" character varying(255) NOT NULL,
    "phoneNumber" character varying(255) NOT NULL,
    status boolean NOT NULL,
    "webId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Pharmacies" OWNER TO postgres;

--
-- Name: Pharmacies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Pharmacies_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Pharmacies_id_seq" OWNER TO postgres;

--
-- Name: Pharmacies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Pharmacies_id_seq" OWNED BY public."Pharmacies".id;


--
-- Name: PostCategories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PostCategories" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."PostCategories" OWNER TO postgres;

--
-- Name: PostCategories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PostCategories_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PostCategories_id_seq" OWNER TO postgres;

--
-- Name: PostCategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PostCategories_id_seq" OWNED BY public."PostCategories".id;


--
-- Name: PostTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PostTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."PostTypes" OWNER TO postgres;

--
-- Name: PostTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PostTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PostTypes_id_seq" OWNER TO postgres;

--
-- Name: PostTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PostTypes_id_seq" OWNED BY public."PostTypes".id;


--
-- Name: Posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Posts" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    author character varying(255),
    image character varying(255),
    status boolean NOT NULL,
    "categoryId" integer NOT NULL,
    "postTypeId" integer NOT NULL,
    "eventDetailId" integer,
    "organizationId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Posts" OWNER TO postgres;

--
-- Name: Posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Posts_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Posts_id_seq" OWNER TO postgres;

--
-- Name: Posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Posts_id_seq" OWNED BY public."Posts".id;


--
-- Name: PrePatients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PrePatients" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    surname character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    gender public."enum_PrePatients_gender" NOT NULL,
    birthdate date NOT NULL,
    "phoneNumber" character varying(255) NOT NULL,
    cedula character varying(255) NOT NULL,
    description character varying(255),
    status character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."PrePatients" OWNER TO postgres;

--
-- Name: PrePatients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PrePatients_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PrePatients_id_seq" OWNER TO postgres;

--
-- Name: PrePatients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PrePatients_id_seq" OWNED BY public."PrePatients".id;


--
-- Name: RatingTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RatingTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    entity public."enum_RatingTypes_entity" NOT NULL,
    scale public."enum_RatingTypes_scale" NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."RatingTypes" OWNER TO postgres;

--
-- Name: RatingTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RatingTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."RatingTypes_id_seq" OWNER TO postgres;

--
-- Name: RatingTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RatingTypes_id_seq" OWNED BY public."RatingTypes".id;


--
-- Name: Ratings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ratings" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "serviceId" integer,
    "eventDetailId" integer,
    "ratingTypeId" integer NOT NULL,
    stars integer,
    response text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Ratings" OWNER TO postgres;

--
-- Name: Ratings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Ratings_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Ratings_id_seq" OWNER TO postgres;

--
-- Name: Ratings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Ratings_id_seq" OWNED BY public."Ratings".id;


--
-- Name: RequestTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RequestTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."RequestTypes" OWNER TO postgres;

--
-- Name: RequestTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RequestTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."RequestTypes_id_seq" OWNER TO postgres;

--
-- Name: RequestTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RequestTypes_id_seq" OWNED BY public."RequestTypes".id;


--
-- Name: Requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Requests" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "activityTypeId" integer,
    "requestTypeId" integer NOT NULL,
    status boolean,
    description text NOT NULL,
    response text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Requests" OWNER TO postgres;

--
-- Name: Requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Requests_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Requests_id_seq" OWNER TO postgres;

--
-- Name: Requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Requests_id_seq" OWNED BY public."Requests".id;


--
-- Name: Resources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Resources" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Resources" OWNER TO postgres;

--
-- Name: Resources_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Resources_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Resources_id_seq" OWNER TO postgres;

--
-- Name: Resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Resources_id_seq" OWNED BY public."Resources".id;


--
-- Name: ResultParameters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ResultParameters" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."ResultParameters" OWNER TO postgres;

--
-- Name: ResultParameters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ResultParameters_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ResultParameters_id_seq" OWNER TO postgres;

--
-- Name: ResultParameters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ResultParameters_id_seq" OWNED BY public."ResultParameters".id;


--
-- Name: RiskFactorDiagnoses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RiskFactorDiagnoses" (
    id integer NOT NULL,
    status boolean NOT NULL,
    "riskFactorId" integer NOT NULL,
    "appointmentHistoryId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."RiskFactorDiagnoses" OWNER TO postgres;

--
-- Name: RiskFactorDiagnoses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RiskFactorDiagnoses_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."RiskFactorDiagnoses_id_seq" OWNER TO postgres;

--
-- Name: RiskFactorDiagnoses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RiskFactorDiagnoses_id_seq" OWNED BY public."RiskFactorDiagnoses".id;


--
-- Name: RiskFactors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RiskFactors" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."RiskFactors" OWNER TO postgres;

--
-- Name: RiskFactors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RiskFactors_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."RiskFactors_id_seq" OWNER TO postgres;

--
-- Name: RiskFactors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RiskFactors_id_seq" OWNED BY public."RiskFactors".id;


--
-- Name: Roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Roles" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Roles" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Roles_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Roles_id_seq" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Roles_id_seq" OWNED BY public."Roles".id;


--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO postgres;

--
-- Name: ServiceRatingTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServiceRatingTypes" (
    id integer NOT NULL,
    "ratingTypeId" integer NOT NULL,
    "serviceId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."ServiceRatingTypes" OWNER TO postgres;

--
-- Name: ServiceRatingTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ServiceRatingTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ServiceRatingTypes_id_seq" OWNER TO postgres;

--
-- Name: ServiceRatingTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ServiceRatingTypes_id_seq" OWNED BY public."ServiceRatingTypes".id;


--
-- Name: ServiceTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServiceTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    status boolean DEFAULT true NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."ServiceTypes" OWNER TO postgres;

--
-- Name: ServiceTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ServiceTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ServiceTypes_id_seq" OWNER TO postgres;

--
-- Name: ServiceTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ServiceTypes_id_seq" OWNED BY public."ServiceTypes".id;


--
-- Name: Services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Services" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    icon character varying(255) NOT NULL,
    status boolean NOT NULL,
    "typeId" integer NOT NULL,
    "specialityId" integer NOT NULL,
    "organizationId" integer NOT NULL,
    visibility boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Services" OWNER TO postgres;

--
-- Name: Services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Services_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Services_id_seq" OWNER TO postgres;

--
-- Name: Services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Services_id_seq" OWNED BY public."Services".id;


--
-- Name: Specialities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Specialities" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    "personTypeId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Specialities" OWNER TO postgres;

--
-- Name: Specialities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Specialities_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Specialities_id_seq" OWNER TO postgres;

--
-- Name: Specialities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Specialities_id_seq" OWNED BY public."Specialities".id;


--
-- Name: SystemFunctionRoles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SystemFunctionRoles" (
    id integer NOT NULL,
    status boolean NOT NULL,
    "systemFunctionId" integer NOT NULL,
    "roleId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."SystemFunctionRoles" OWNER TO postgres;

--
-- Name: SystemFunctionRoles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SystemFunctionRoles_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SystemFunctionRoles_id_seq" OWNER TO postgres;

--
-- Name: SystemFunctionRoles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SystemFunctionRoles_id_seq" OWNED BY public."SystemFunctionRoles".id;


--
-- Name: SystemFunctions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SystemFunctions" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status boolean NOT NULL,
    "parentId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."SystemFunctions" OWNER TO postgres;

--
-- Name: SystemFunctions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SystemFunctions_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SystemFunctions_id_seq" OWNER TO postgres;

--
-- Name: SystemFunctions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SystemFunctions_id_seq" OWNED BY public."SystemFunctions".id;


--
-- Name: Timetables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Timetables" (
    id integer NOT NULL,
    description character varying(255) NOT NULL,
    status boolean NOT NULL,
    day public."enum_Timetables_day" NOT NULL,
    "timeStart" time without time zone NOT NULL,
    "timeEnd" time without time zone NOT NULL,
    "dayNumber" integer NOT NULL,
    "maxPatients" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Timetables" OWNER TO postgres;

--
-- Name: Timetables_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Timetables_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Timetables_id_seq" OWNER TO postgres;

--
-- Name: Timetables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Timetables_id_seq" OWNED BY public."Timetables".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    "profilePicture" character varying(255),
    notifications boolean,
    "mobileApp" boolean,
    "lastLoginAt" timestamp with time zone,
    status boolean NOT NULL,
    "roleId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Users_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO postgres;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: WebContents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WebContents" (
    id integer NOT NULL,
    "initialDescription" text,
    "weImage" character varying(255),
    "weDescription" text,
    "serviceDescription" text,
    "interestDescription" text,
    "newsDescription" text,
    "eventsDescription" text,
    "downloadDescription" text,
    "downloadImage" character varying(255),
    "voluntaryTitle" character varying(255),
    "voluntaryMessage" text,
    "voluntaryDescription" text,
    "donationTitle" character varying(255),
    "donationMessage" text,
    "donationDescription" text,
    "sitesTitle" character varying(255),
    "sitesMessage" text,
    "maxService" integer,
    "maxGeneral" integer,
    "mainImage" character varying(255),
    "missionImage" character varying(255),
    "visionImage" character varying(255),
    "targetImage" character varying(255),
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone NOT NULL,
    "deletedAt" timestamp with time zone
);


ALTER TABLE public."WebContents" OWNER TO postgres;

--
-- Name: WebContents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."WebContents_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."WebContents_id_seq" OWNER TO postgres;

--
-- Name: WebContents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."WebContents_id_seq" OWNED BY public."WebContents".id;


--
-- Name: AppointmentCancelTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentCancelTypes" ALTER COLUMN id SET DEFAULT nextval('public."AppointmentCancelTypes_id_seq"'::regclass);


--
-- Name: AppointmentHistories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentHistories" ALTER COLUMN id SET DEFAULT nextval('public."AppointmentHistories_id_seq"'::regclass);


--
-- Name: AppointmentTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentTypes" ALTER COLUMN id SET DEFAULT nextval('public."AppointmentTypes_id_seq"'::regclass);


--
-- Name: Appointments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments" ALTER COLUMN id SET DEFAULT nextval('public."Appointments_id_seq"'::regclass);


--
-- Name: AssignedDonatives id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssignedDonatives" ALTER COLUMN id SET DEFAULT nextval('public."AssignedDonatives_id_seq"'::regclass);


--
-- Name: Bitacoras id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Bitacoras" ALTER COLUMN id SET DEFAULT nextval('public."Bitacoras_id_seq"'::regclass);


--
-- Name: Comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comments" ALTER COLUMN id SET DEFAULT nextval('public."Comments_id_seq"'::regclass);


--
-- Name: DiabetesTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DiabetesTypes" ALTER COLUMN id SET DEFAULT nextval('public."DiabetesTypes_id_seq"'::regclass);


--
-- Name: DonationTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DonationTypes" ALTER COLUMN id SET DEFAULT nextval('public."DonationTypes_id_seq"'::regclass);


--
-- Name: Donations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Donations" ALTER COLUMN id SET DEFAULT nextval('public."Donations_id_seq"'::regclass);


--
-- Name: Donatives id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Donatives" ALTER COLUMN id SET DEFAULT nextval('public."Donatives_id_seq"'::regclass);


--
-- Name: EconomicStatuses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EconomicStatuses" ALTER COLUMN id SET DEFAULT nextval('public."EconomicStatuses_id_seq"'::regclass);


--
-- Name: EventCancelTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventCancelTypes" ALTER COLUMN id SET DEFAULT nextval('public."EventCancelTypes_id_seq"'::regclass);


--
-- Name: EventContingencies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventContingencies" ALTER COLUMN id SET DEFAULT nextval('public."EventContingencies_id_seq"'::regclass);


--
-- Name: EventDetailPatients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventDetailPatients" ALTER COLUMN id SET DEFAULT nextval('public."EventDetailPatients_id_seq"'::regclass);


--
-- Name: EventDetails id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventDetails" ALTER COLUMN id SET DEFAULT nextval('public."EventDetails_id_seq"'::regclass);


--
-- Name: EventParticipants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventParticipants" ALTER COLUMN id SET DEFAULT nextval('public."EventParticipants_id_seq"'::regclass);


--
-- Name: EventRatingTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventRatingTypes" ALTER COLUMN id SET DEFAULT nextval('public."EventRatingTypes_id_seq"'::regclass);


--
-- Name: EventResources id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventResources" ALTER COLUMN id SET DEFAULT nextval('public."EventResources_id_seq"'::regclass);


--
-- Name: EventResultParameters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventResultParameters" ALTER COLUMN id SET DEFAULT nextval('public."EventResultParameters_id_seq"'::regclass);


--
-- Name: EventTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventTypes" ALTER COLUMN id SET DEFAULT nextval('public."EventTypes_id_seq"'::regclass);


--
-- Name: Events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Events" ALTER COLUMN id SET DEFAULT nextval('public."Events_id_seq"'::regclass);


--
-- Name: Faqs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Faqs" ALTER COLUMN id SET DEFAULT nextval('public."Faqs_id_seq"'::regclass);


--
-- Name: GeneralInformations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GeneralInformations" ALTER COLUMN id SET DEFAULT nextval('public."GeneralInformations_id_seq"'::regclass);


--
-- Name: GlucoseMeasurements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GlucoseMeasurements" ALTER COLUMN id SET DEFAULT nextval('public."GlucoseMeasurements_id_seq"'::regclass);


--
-- Name: Guests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Guests" ALTER COLUMN id SET DEFAULT nextval('public."Guests_id_seq"'::regclass);


--
-- Name: IllnessDiagnoses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IllnessDiagnoses" ALTER COLUMN id SET DEFAULT nextval('public."IllnessDiagnoses_id_seq"'::regclass);


--
-- Name: Illnesses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Illnesses" ALTER COLUMN id SET DEFAULT nextval('public."Illnesses_id_seq"'::regclass);


--
-- Name: LegalGuardians id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LegalGuardians" ALTER COLUMN id SET DEFAULT nextval('public."LegalGuardians_id_seq"'::regclass);


--
-- Name: MeasurementTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MeasurementTypes" ALTER COLUMN id SET DEFAULT nextval('public."MeasurementTypes_id_seq"'::regclass);


--
-- Name: MedicalCenters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicalCenters" ALTER COLUMN id SET DEFAULT nextval('public."MedicalCenters_id_seq"'::regclass);


--
-- Name: MedicalRecords id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicalRecords" ALTER COLUMN id SET DEFAULT nextval('public."MedicalRecords_id_seq"'::regclass);


--
-- Name: MessageCancelTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MessageCancelTypes" ALTER COLUMN id SET DEFAULT nextval('public."MessageCancelTypes_id_seq"'::regclass);


--
-- Name: MessageTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MessageTypes" ALTER COLUMN id SET DEFAULT nextval('public."MessageTypes_id_seq"'::regclass);


--
-- Name: Messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Messages" ALTER COLUMN id SET DEFAULT nextval('public."Messages_id_seq"'::regclass);


--
-- Name: NotificationTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationTypes" ALTER COLUMN id SET DEFAULT nextval('public."NotificationTypes_id_seq"'::regclass);


--
-- Name: Notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notifications" ALTER COLUMN id SET DEFAULT nextval('public."Notifications_id_seq"'::regclass);


--
-- Name: Organizations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Organizations" ALTER COLUMN id SET DEFAULT nextval('public."Organizations_id_seq"'::regclass);


--
-- Name: ParticipantTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParticipantTypes" ALTER COLUMN id SET DEFAULT nextval('public."ParticipantTypes_id_seq"'::regclass);


--
-- Name: Patients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patients" ALTER COLUMN id SET DEFAULT nextval('public."Patients_id_seq"'::regclass);


--
-- Name: People id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."People" ALTER COLUMN id SET DEFAULT nextval('public."People_id_seq"'::regclass);


--
-- Name: PersonTimetables id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonTimetables" ALTER COLUMN id SET DEFAULT nextval('public."PersonTimetables_id_seq"'::regclass);


--
-- Name: PersonTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonTypes" ALTER COLUMN id SET DEFAULT nextval('public."PersonTypes_id_seq"'::regclass);


--
-- Name: Pharmacies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pharmacies" ALTER COLUMN id SET DEFAULT nextval('public."Pharmacies_id_seq"'::regclass);


--
-- Name: PostCategories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PostCategories" ALTER COLUMN id SET DEFAULT nextval('public."PostCategories_id_seq"'::regclass);


--
-- Name: PostTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PostTypes" ALTER COLUMN id SET DEFAULT nextval('public."PostTypes_id_seq"'::regclass);


--
-- Name: Posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Posts" ALTER COLUMN id SET DEFAULT nextval('public."Posts_id_seq"'::regclass);


--
-- Name: PrePatients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PrePatients" ALTER COLUMN id SET DEFAULT nextval('public."PrePatients_id_seq"'::regclass);


--
-- Name: RatingTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RatingTypes" ALTER COLUMN id SET DEFAULT nextval('public."RatingTypes_id_seq"'::regclass);


--
-- Name: Ratings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ratings" ALTER COLUMN id SET DEFAULT nextval('public."Ratings_id_seq"'::regclass);


--
-- Name: RequestTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RequestTypes" ALTER COLUMN id SET DEFAULT nextval('public."RequestTypes_id_seq"'::regclass);


--
-- Name: Requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Requests" ALTER COLUMN id SET DEFAULT nextval('public."Requests_id_seq"'::regclass);


--
-- Name: Resources id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Resources" ALTER COLUMN id SET DEFAULT nextval('public."Resources_id_seq"'::regclass);


--
-- Name: ResultParameters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResultParameters" ALTER COLUMN id SET DEFAULT nextval('public."ResultParameters_id_seq"'::regclass);


--
-- Name: RiskFactorDiagnoses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RiskFactorDiagnoses" ALTER COLUMN id SET DEFAULT nextval('public."RiskFactorDiagnoses_id_seq"'::regclass);


--
-- Name: RiskFactors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RiskFactors" ALTER COLUMN id SET DEFAULT nextval('public."RiskFactors_id_seq"'::regclass);


--
-- Name: Roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles" ALTER COLUMN id SET DEFAULT nextval('public."Roles_id_seq"'::regclass);


--
-- Name: ServiceRatingTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceRatingTypes" ALTER COLUMN id SET DEFAULT nextval('public."ServiceRatingTypes_id_seq"'::regclass);


--
-- Name: ServiceTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceTypes" ALTER COLUMN id SET DEFAULT nextval('public."ServiceTypes_id_seq"'::regclass);


--
-- Name: Services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Services" ALTER COLUMN id SET DEFAULT nextval('public."Services_id_seq"'::regclass);


--
-- Name: Specialities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Specialities" ALTER COLUMN id SET DEFAULT nextval('public."Specialities_id_seq"'::regclass);


--
-- Name: SystemFunctionRoles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemFunctionRoles" ALTER COLUMN id SET DEFAULT nextval('public."SystemFunctionRoles_id_seq"'::regclass);


--
-- Name: SystemFunctions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemFunctions" ALTER COLUMN id SET DEFAULT nextval('public."SystemFunctions_id_seq"'::regclass);


--
-- Name: Timetables id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Timetables" ALTER COLUMN id SET DEFAULT nextval('public."Timetables_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Name: WebContents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WebContents" ALTER COLUMN id SET DEFAULT nextval('public."WebContents_id_seq"'::regclass);


--
-- Data for Name: AppointmentCancelTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppointmentCancelTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."AppointmentCancelTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3033.dat';

--
-- Name: AppointmentCancelTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppointmentCancelTypes_id_seq"', 4, true);


--
-- Data for Name: AppointmentHistories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppointmentHistories" (id, "appointmentId", "medicalRecordId", "glucoseLevel", height, weight, "bloodPressureUp", "bloodPressureDown", "physicalExamination", treatments, "medicalConditions", description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."AppointmentHistories" (id, "appointmentId", "medicalRecordId", "glucoseLevel", height, weight, "bloodPressureUp", "bloodPressureDown", "physicalExamination", treatments, "medicalConditions", description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3031.dat';

--
-- Name: AppointmentHistories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppointmentHistories_id_seq"', 3, true);


--
-- Data for Name: AppointmentTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AppointmentTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."AppointmentTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2993.dat';

--
-- Name: AppointmentTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AppointmentTypes_id_seq"', 3, true);


--
-- Data for Name: Appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Appointments" (id, "patientId", "prePatientId", "typeId", "serviceId", "personId", date, description, status, "statusAppointment", "dayNumber", "timetableId", qualified, "createdAt", "updatedAt", "deletedAt", "cancelId") FROM stdin;
\.
COPY public."Appointments" (id, "patientId", "prePatientId", "typeId", "serviceId", "personId", date, description, status, "statusAppointment", "dayNumber", "timetableId", qualified, "createdAt", "updatedAt", "deletedAt", "cancelId") FROM '$$PATH$$/3029.dat';

--
-- Name: Appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Appointments_id_seq"', 18, true);


--
-- Data for Name: AssignedDonatives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AssignedDonatives" (id, "patientId", "donativeId", "assignationDate", description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."AssignedDonatives" (id, "patientId", "donativeId", "assignationDate", description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3037.dat';

--
-- Name: AssignedDonatives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AssignedDonatives_id_seq"', 2, true);


--
-- Data for Name: Bitacoras; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Bitacoras" (id, "modelName", "recordId", "recordName", operation, "userId", date, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Bitacoras" (id, "modelName", "recordId", "recordName", operation, "userId", date, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3051.dat';

--
-- Name: Bitacoras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Bitacoras_id_seq"', 1, true);


--
-- Data for Name: Comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Comments" (id, message, status, "userId", "postId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Comments" (id, message, status, "userId", "postId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3069.dat';

--
-- Name: Comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Comments_id_seq"', 3, true);


--
-- Data for Name: DiabetesTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DiabetesTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."DiabetesTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3041.dat';

--
-- Name: DiabetesTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DiabetesTypes_id_seq"', 3, true);


--
-- Data for Name: DonationTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DonationTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."DonationTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2949.dat';

--
-- Name: DonationTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DonationTypes_id_seq"', 3, true);


--
-- Data for Name: Donations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Donations" (id, name, "lastName", email, phone, description, status, "donativeId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Donations" (id, name, "lastName", email, phone, description, status, "donativeId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2971.dat';

--
-- Name: Donations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Donations_id_seq"', 5, true);


--
-- Data for Name: Donatives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Donatives" (id, name, description, status, "typeId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Donatives" (id, name, description, status, "typeId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2969.dat';

--
-- Name: Donatives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Donatives_id_seq"', 13, true);


--
-- Data for Name: EconomicStatuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EconomicStatuses" (id, "familyHead", housing, insurance, "monthlySalary", "familyMembers", other, status, "medicalRecordId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EconomicStatuses" (id, "familyHead", housing, insurance, "monthlySalary", "familyMembers", other, status, "medicalRecordId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3025.dat';

--
-- Name: EconomicStatuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EconomicStatuses_id_seq"', 3, true);


--
-- Data for Name: EventCancelTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventCancelTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EventCancelTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3039.dat';

--
-- Name: EventCancelTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventCancelTypes_id_seq"', 4, true);


--
-- Data for Name: EventContingencies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventContingencies" (id, "eventDetailId", "eventCancelId", "initialDate", "initialTime", status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EventContingencies" (id, "eventDetailId", "eventCancelId", "initialDate", "initialTime", status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3065.dat';

--
-- Name: EventContingencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventContingencies_id_seq"', 2, true);


--
-- Data for Name: EventDetailPatients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventDetailPatients" (id, "eventDetailId", "patientId", status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EventDetailPatients" (id, "eventDetailId", "patientId", status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3077.dat';

--
-- Name: EventDetailPatients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventDetailPatients_id_seq"', 1, false);


--
-- Data for Name: EventDetails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventDetails" (id, "eventId", status, evaluation, "statusDetail", name, "plannedDate", "time", "realDate", place, description, image, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EventDetails" (id, "eventId", status, evaluation, "statusDetail", name, "plannedDate", "time", "realDate", place, description, image, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3055.dat';

--
-- Name: EventDetails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventDetails_id_seq"', 7, true);


--
-- Data for Name: EventParticipants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventParticipants" (id, "eventDetailId", "participantTypeId", "userId", "assistedEvent", status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EventParticipants" (id, "eventDetailId", "participantTypeId", "userId", "assistedEvent", status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3063.dat';

--
-- Name: EventParticipants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventParticipants_id_seq"', 14, true);


--
-- Data for Name: EventRatingTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventRatingTypes" (id, "ratingTypeId", "eventId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EventRatingTypes" (id, "ratingTypeId", "eventId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3073.dat';

--
-- Name: EventRatingTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventRatingTypes_id_seq"', 10, true);


--
-- Data for Name: EventResources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventResources" (id, "eventDetailId", "resourceId", quantity, description, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EventResources" (id, "eventDetailId", "resourceId", quantity, description, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3061.dat';

--
-- Name: EventResources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventResources_id_seq"', 8, true);


--
-- Data for Name: EventResultParameters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventResultParameters" (id, "eventDetailId", "resultParameterId", "minValue", "maxValue", "realValue", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EventResultParameters" (id, "eventDetailId", "resultParameterId", "minValue", "maxValue", "realValue", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3057.dat';

--
-- Name: EventResultParameters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventResultParameters_id_seq"', 11, true);


--
-- Data for Name: EventTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."EventTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2991.dat';

--
-- Name: EventTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventTypes_id_seq"', 3, true);


--
-- Data for Name: Events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Events" (id, name, topic, description, "eventTypeId", status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Events" (id, name, topic, description, "eventTypeId", status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3053.dat';

--
-- Name: Events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Events_id_seq"', 5, true);


--
-- Data for Name: Faqs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Faqs" (id, question, answer, status, "organizationId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Faqs" (id, question, answer, status, "organizationId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2953.dat';

--
-- Name: Faqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Faqs_id_seq"', 4, true);


--
-- Data for Name: GeneralInformations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GeneralInformations" (id, title, description, image, status, "webId", visibility, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."GeneralInformations" (id, title, description, image, status, "webId", visibility, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2979.dat';

--
-- Name: GeneralInformations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GeneralInformations_id_seq"', 4, true);


--
-- Data for Name: GlucoseMeasurements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GlucoseMeasurements" (id, "measurementTypeId", "patientId", status, result, "resultDate", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."GlucoseMeasurements" (id, "measurementTypeId", "patientId", status, result, "resultDate", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3027.dat';

--
-- Name: GlucoseMeasurements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GlucoseMeasurements_id_seq"', 1, true);


--
-- Data for Name: Guests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Guests" (id, "eventDetailId", status, name, email, phone, occupations, description, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Guests" (id, "eventDetailId", status, name, email, phone, occupations, description, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3059.dat';

--
-- Name: Guests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Guests_id_seq"', 7, true);


--
-- Data for Name: IllnessDiagnoses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."IllnessDiagnoses" (id, status, "illnessId", "appointmentHistoryId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."IllnessDiagnoses" (id, status, "illnessId", "appointmentHistoryId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3045.dat';

--
-- Name: IllnessDiagnoses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."IllnessDiagnoses_id_seq"', 7, true);


--
-- Data for Name: Illnesses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Illnesses" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Illnesses" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2959.dat';

--
-- Name: Illnesses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Illnesses_id_seq"', 6, true);


--
-- Data for Name: LegalGuardians; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LegalGuardians" (id, "patientId", status, name, surname, gender, birthdate, relationship, "phoneNumber", address, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."LegalGuardians" (id, "patientId", status, name, surname, gender, birthdate, relationship, "phoneNumber", address, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3021.dat';

--
-- Name: LegalGuardians_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LegalGuardians_id_seq"', 1, true);


--
-- Data for Name: MeasurementTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MeasurementTypes" (id, name, description, status, "lowerRank", "upperRank", "dangerLevel", "upperMessage", "downMessage", "inRangeMessage", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."MeasurementTypes" (id, name, description, status, "lowerRank", "upperRank", "dangerLevel", "upperMessage", "downMessage", "inRangeMessage", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3003.dat';

--
-- Name: MeasurementTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MeasurementTypes_id_seq"', 3, true);


--
-- Data for Name: MedicalCenters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MedicalCenters" (id, name, description, address, "addressUrl", "phoneNumber", status, "webId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."MedicalCenters" (id, name, description, address, "addressUrl", "phoneNumber", status, "webId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2975.dat';

--
-- Name: MedicalCenters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MedicalCenters_id_seq"', 3, true);


--
-- Data for Name: MedicalRecords; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MedicalRecords" (id, "bloodType", "personalBackground", "familyBackground", status, "patientId", amputated, "createdAt", "updatedAt", "deletedAt", "diabetesId") FROM stdin;
\.
COPY public."MedicalRecords" (id, "bloodType", "personalBackground", "familyBackground", status, "patientId", amputated, "createdAt", "updatedAt", "deletedAt", "diabetesId") FROM '$$PATH$$/3023.dat';

--
-- Name: MedicalRecords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MedicalRecords_id_seq"', 3, true);


--
-- Data for Name: MessageCancelTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MessageCancelTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."MessageCancelTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3035.dat';

--
-- Name: MessageCancelTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MessageCancelTypes_id_seq"', 4, true);


--
-- Data for Name: MessageTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MessageTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."MessageTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2983.dat';

--
-- Name: MessageTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MessageTypes_id_seq"', 6, true);


--
-- Data for Name: Messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Messages" (id, "senderName", "senderEmail", subject, "messageContent", "phoneNumber", status, "organizationId", "typeId", "userId", "cancelId", canceled, "attentionDate", response, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Messages" (id, "senderName", "senderEmail", subject, "messageContent", "phoneNumber", status, "organizationId", "typeId", "userId", "cancelId", canceled, "attentionDate", response, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3047.dat';

--
-- Name: Messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Messages_id_seq"', 2, true);


--
-- Data for Name: NotificationTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NotificationTypes" (id, name, message, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."NotificationTypes" (id, name, message, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3013.dat';

--
-- Name: NotificationTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."NotificationTypes_id_seq"', 13, true);


--
-- Data for Name: Notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notifications" (id, "typeId", "userId", "modelId", model, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Notifications" (id, "typeId", "userId", "modelId", model, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3079.dat';

--
-- Name: Notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Notifications_id_seq"', 13, true);


--
-- Data for Name: Organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Organizations" (id, name, description, status, address, "addressUrl", mission, vission, "values", objective, "apkUrl", apk, image, phone, "phoneTwo", email, rif, history, "colorPrimary", "colorSecondary", "facebookUsername", "instagramUsername", "twitterUsername", "linkedinUsername", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Organizations" (id, name, description, status, address, "addressUrl", mission, vission, "values", objective, "apkUrl", apk, image, phone, "phoneTwo", email, rif, history, "colorPrimary", "colorSecondary", "facebookUsername", "instagramUsername", "twitterUsername", "linkedinUsername", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2951.dat';

--
-- Name: Organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Organizations_id_seq"', 1, true);


--
-- Data for Name: ParticipantTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ParticipantTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."ParticipantTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2995.dat';

--
-- Name: ParticipantTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ParticipantTypes_id_seq"', 4, true);


--
-- Data for Name: Patients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Patients" (id, name, surname, gender, birthdate, "phoneNumber", "maritalStatus", address, cedula, rif, "userId", status, transaction, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Patients" (id, name, surname, gender, birthdate, "phoneNumber", "maritalStatus", address, cedula, rif, "userId", status, transaction, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3019.dat';

--
-- Name: Patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Patients_id_seq"', 3, true);


--
-- Data for Name: People; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."People" (id, name, surname, gender, birthdate, "phoneNumber", address, cedula, rif, description, "userId", "specialityId", status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."People" (id, name, surname, gender, birthdate, "phoneNumber", address, cedula, rif, description, "userId", "specialityId", status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3011.dat';

--
-- Name: People_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."People_id_seq"', 20, true);


--
-- Data for Name: PersonTimetables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PersonTimetables" (id, status, "personId", "timetableId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."PersonTimetables" (id, status, "personId", "timetableId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3015.dat';

--
-- Name: PersonTimetables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PersonTimetables_id_seq"', 63, true);


--
-- Data for Name: PersonTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PersonTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."PersonTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2963.dat';

--
-- Name: PersonTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PersonTypes_id_seq"', 2, true);


--
-- Data for Name: Pharmacies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Pharmacies" (id, name, description, address, "addressUrl", "phoneNumber", status, "webId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Pharmacies" (id, name, description, address, "addressUrl", "phoneNumber", status, "webId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2977.dat';

--
-- Name: Pharmacies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Pharmacies_id_seq"', 3, true);


--
-- Data for Name: PostCategories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PostCategories" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."PostCategories" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2989.dat';

--
-- Name: PostCategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PostCategories_id_seq"', 4, true);


--
-- Data for Name: PostTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PostTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."PostTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2987.dat';

--
-- Name: PostTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PostTypes_id_seq"', 2, true);


--
-- Data for Name: Posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Posts" (id, title, content, author, image, status, "categoryId", "postTypeId", "eventDetailId", "organizationId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Posts" (id, title, content, author, image, status, "categoryId", "postTypeId", "eventDetailId", "organizationId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3067.dat';

--
-- Name: Posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Posts_id_seq"', 6, true);


--
-- Data for Name: PrePatients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PrePatients" (id, name, surname, email, gender, birthdate, "phoneNumber", cedula, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."PrePatients" (id, name, surname, email, gender, birthdate, "phoneNumber", cedula, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3017.dat';

--
-- Name: PrePatients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PrePatients_id_seq"', 10, true);


--
-- Data for Name: RatingTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RatingTypes" (id, name, description, entity, scale, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."RatingTypes" (id, name, description, entity, scale, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3005.dat';

--
-- Name: RatingTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RatingTypes_id_seq"', 8, true);


--
-- Data for Name: Ratings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ratings" (id, "userId", "serviceId", "eventDetailId", "ratingTypeId", stars, response, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Ratings" (id, "userId", "serviceId", "eventDetailId", "ratingTypeId", stars, response, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3071.dat';

--
-- Name: Ratings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ratings_id_seq"', 4, true);


--
-- Data for Name: RequestTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RequestTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."RequestTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2999.dat';

--
-- Name: RequestTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RequestTypes_id_seq"', 5, true);


--
-- Data for Name: Requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Requests" (id, "userId", "activityTypeId", "requestTypeId", status, description, response, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Requests" (id, "userId", "activityTypeId", "requestTypeId", status, description, response, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3049.dat';

--
-- Name: Requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Requests_id_seq"', 2, true);


--
-- Data for Name: Resources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Resources" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Resources" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2997.dat';

--
-- Name: Resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Resources_id_seq"', 4, true);


--
-- Data for Name: ResultParameters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ResultParameters" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."ResultParameters" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3001.dat';

--
-- Name: ResultParameters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ResultParameters_id_seq"', 4, true);


--
-- Data for Name: RiskFactorDiagnoses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RiskFactorDiagnoses" (id, status, "riskFactorId", "appointmentHistoryId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."RiskFactorDiagnoses" (id, status, "riskFactorId", "appointmentHistoryId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3043.dat';

--
-- Name: RiskFactorDiagnoses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RiskFactorDiagnoses_id_seq"', 6, true);


--
-- Data for Name: RiskFactors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RiskFactors" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."RiskFactors" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2961.dat';

--
-- Name: RiskFactors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RiskFactors_id_seq"', 7, true);


--
-- Data for Name: Roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Roles" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Roles" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2957.dat';

--
-- Name: Roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Roles_id_seq"', 7, true);


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SequelizeMeta" (name) FROM stdin;
\.
COPY public."SequelizeMeta" (name) FROM '$$PATH$$/2947.dat';

--
-- Data for Name: ServiceRatingTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServiceRatingTypes" (id, "ratingTypeId", "serviceId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."ServiceRatingTypes" (id, "ratingTypeId", "serviceId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3075.dat';

--
-- Name: ServiceRatingTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ServiceRatingTypes_id_seq"', 12, true);


--
-- Data for Name: ServiceTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServiceTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."ServiceTypes" (id, name, description, status, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2955.dat';

--
-- Name: ServiceTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ServiceTypes_id_seq"', 7, true);


--
-- Data for Name: Services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Services" (id, name, description, icon, status, "typeId", "specialityId", "organizationId", visibility, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Services" (id, name, description, icon, status, "typeId", "specialityId", "organizationId", visibility, "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2981.dat';

--
-- Name: Services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Services_id_seq"', 8, true);


--
-- Data for Name: Specialities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Specialities" (id, name, description, status, "personTypeId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Specialities" (id, name, description, status, "personTypeId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2965.dat';

--
-- Name: Specialities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Specialities_id_seq"', 10, true);


--
-- Data for Name: SystemFunctionRoles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SystemFunctionRoles" (id, status, "systemFunctionId", "roleId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."SystemFunctionRoles" (id, status, "systemFunctionId", "roleId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2985.dat';

--
-- Name: SystemFunctionRoles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SystemFunctionRoles_id_seq"', 252, true);


--
-- Data for Name: SystemFunctions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SystemFunctions" (id, name, description, status, "parentId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."SystemFunctions" (id, name, description, status, "parentId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2967.dat';

--
-- Name: SystemFunctions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SystemFunctions_id_seq"', 92, true);


--
-- Data for Name: Timetables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Timetables" (id, description, status, day, "timeStart", "timeEnd", "dayNumber", "maxPatients", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Timetables" (id, description, status, day, "timeStart", "timeEnd", "dayNumber", "maxPatients", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3009.dat';

--
-- Name: Timetables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Timetables_id_seq"', 13, true);


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" (id, email, username, password, "profilePicture", notifications, "mobileApp", "lastLoginAt", status, "roleId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."Users" (id, email, username, password, "profilePicture", notifications, "mobileApp", "lastLoginAt", status, "roleId", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/3007.dat';

--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Users_id_seq"', 23, true);


--
-- Data for Name: WebContents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WebContents" (id, "initialDescription", "weImage", "weDescription", "serviceDescription", "interestDescription", "newsDescription", "eventsDescription", "downloadDescription", "downloadImage", "voluntaryTitle", "voluntaryMessage", "voluntaryDescription", "donationTitle", "donationMessage", "donationDescription", "sitesTitle", "sitesMessage", "maxService", "maxGeneral", "mainImage", "missionImage", "visionImage", "targetImage", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.
COPY public."WebContents" (id, "initialDescription", "weImage", "weDescription", "serviceDescription", "interestDescription", "newsDescription", "eventsDescription", "downloadDescription", "downloadImage", "voluntaryTitle", "voluntaryMessage", "voluntaryDescription", "donationTitle", "donationMessage", "donationDescription", "sitesTitle", "sitesMessage", "maxService", "maxGeneral", "mainImage", "missionImage", "visionImage", "targetImage", "createdAt", "updatedAt", "deletedAt") FROM '$$PATH$$/2973.dat';

--
-- Name: WebContents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."WebContents_id_seq"', 1, true);


--
-- Name: AppointmentCancelTypes AppointmentCancelTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentCancelTypes"
    ADD CONSTRAINT "AppointmentCancelTypes_name_key" UNIQUE (name);


--
-- Name: AppointmentCancelTypes AppointmentCancelTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentCancelTypes"
    ADD CONSTRAINT "AppointmentCancelTypes_pkey" PRIMARY KEY (id);


--
-- Name: AppointmentHistories AppointmentHistories_appointmentId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentHistories"
    ADD CONSTRAINT "AppointmentHistories_appointmentId_key" UNIQUE ("appointmentId");


--
-- Name: AppointmentHistories AppointmentHistories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentHistories"
    ADD CONSTRAINT "AppointmentHistories_pkey" PRIMARY KEY (id);


--
-- Name: AppointmentTypes AppointmentTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentTypes"
    ADD CONSTRAINT "AppointmentTypes_name_key" UNIQUE (name);


--
-- Name: AppointmentTypes AppointmentTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentTypes"
    ADD CONSTRAINT "AppointmentTypes_pkey" PRIMARY KEY (id);


--
-- Name: Appointments Appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT "Appointments_pkey" PRIMARY KEY (id);


--
-- Name: AssignedDonatives AssignedDonatives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssignedDonatives"
    ADD CONSTRAINT "AssignedDonatives_pkey" PRIMARY KEY (id);


--
-- Name: Bitacoras Bitacoras_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Bitacoras"
    ADD CONSTRAINT "Bitacoras_pkey" PRIMARY KEY (id);


--
-- Name: Comments Comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comments"
    ADD CONSTRAINT "Comments_pkey" PRIMARY KEY (id);


--
-- Name: DiabetesTypes DiabetesTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DiabetesTypes"
    ADD CONSTRAINT "DiabetesTypes_name_key" UNIQUE (name);


--
-- Name: DiabetesTypes DiabetesTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DiabetesTypes"
    ADD CONSTRAINT "DiabetesTypes_pkey" PRIMARY KEY (id);


--
-- Name: DonationTypes DonationTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DonationTypes"
    ADD CONSTRAINT "DonationTypes_name_key" UNIQUE (name);


--
-- Name: DonationTypes DonationTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DonationTypes"
    ADD CONSTRAINT "DonationTypes_pkey" PRIMARY KEY (id);


--
-- Name: Donations Donations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Donations"
    ADD CONSTRAINT "Donations_pkey" PRIMARY KEY (id);


--
-- Name: Donatives Donatives_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Donatives"
    ADD CONSTRAINT "Donatives_name_key" UNIQUE (name);


--
-- Name: Donatives Donatives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Donatives"
    ADD CONSTRAINT "Donatives_pkey" PRIMARY KEY (id);


--
-- Name: EconomicStatuses EconomicStatuses_medicalRecordId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EconomicStatuses"
    ADD CONSTRAINT "EconomicStatuses_medicalRecordId_key" UNIQUE ("medicalRecordId");


--
-- Name: EconomicStatuses EconomicStatuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EconomicStatuses"
    ADD CONSTRAINT "EconomicStatuses_pkey" PRIMARY KEY (id);


--
-- Name: EventCancelTypes EventCancelTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventCancelTypes"
    ADD CONSTRAINT "EventCancelTypes_name_key" UNIQUE (name);


--
-- Name: EventCancelTypes EventCancelTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventCancelTypes"
    ADD CONSTRAINT "EventCancelTypes_pkey" PRIMARY KEY (id);


--
-- Name: EventContingencies EventContingencies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventContingencies"
    ADD CONSTRAINT "EventContingencies_pkey" PRIMARY KEY (id);


--
-- Name: EventDetailPatients EventDetailPatients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventDetailPatients"
    ADD CONSTRAINT "EventDetailPatients_pkey" PRIMARY KEY (id);


--
-- Name: EventDetails EventDetails_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventDetails"
    ADD CONSTRAINT "EventDetails_pkey" PRIMARY KEY (id);


--
-- Name: EventParticipants EventParticipants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventParticipants"
    ADD CONSTRAINT "EventParticipants_pkey" PRIMARY KEY (id);


--
-- Name: EventRatingTypes EventRatingTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventRatingTypes"
    ADD CONSTRAINT "EventRatingTypes_pkey" PRIMARY KEY (id);


--
-- Name: EventResources EventResources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventResources"
    ADD CONSTRAINT "EventResources_pkey" PRIMARY KEY (id);


--
-- Name: EventResultParameters EventResultParameters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventResultParameters"
    ADD CONSTRAINT "EventResultParameters_pkey" PRIMARY KEY (id);


--
-- Name: EventTypes EventTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventTypes"
    ADD CONSTRAINT "EventTypes_name_key" UNIQUE (name);


--
-- Name: EventTypes EventTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventTypes"
    ADD CONSTRAINT "EventTypes_pkey" PRIMARY KEY (id);


--
-- Name: Events Events_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Events"
    ADD CONSTRAINT "Events_name_key" UNIQUE (name);


--
-- Name: Events Events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Events"
    ADD CONSTRAINT "Events_pkey" PRIMARY KEY (id);


--
-- Name: Faqs Faqs_answer_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Faqs"
    ADD CONSTRAINT "Faqs_answer_key" UNIQUE (answer);


--
-- Name: Faqs Faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Faqs"
    ADD CONSTRAINT "Faqs_pkey" PRIMARY KEY (id);


--
-- Name: Faqs Faqs_question_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Faqs"
    ADD CONSTRAINT "Faqs_question_key" UNIQUE (question);


--
-- Name: GeneralInformations GeneralInformations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GeneralInformations"
    ADD CONSTRAINT "GeneralInformations_pkey" PRIMARY KEY (id);


--
-- Name: GlucoseMeasurements GlucoseMeasurements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GlucoseMeasurements"
    ADD CONSTRAINT "GlucoseMeasurements_pkey" PRIMARY KEY (id);


--
-- Name: Guests Guests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Guests"
    ADD CONSTRAINT "Guests_pkey" PRIMARY KEY (id);


--
-- Name: IllnessDiagnoses IllnessDiagnoses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IllnessDiagnoses"
    ADD CONSTRAINT "IllnessDiagnoses_pkey" PRIMARY KEY (id);


--
-- Name: Illnesses Illnesses_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Illnesses"
    ADD CONSTRAINT "Illnesses_name_key" UNIQUE (name);


--
-- Name: Illnesses Illnesses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Illnesses"
    ADD CONSTRAINT "Illnesses_pkey" PRIMARY KEY (id);


--
-- Name: LegalGuardians LegalGuardians_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LegalGuardians"
    ADD CONSTRAINT "LegalGuardians_pkey" PRIMARY KEY (id);


--
-- Name: MeasurementTypes MeasurementTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MeasurementTypes"
    ADD CONSTRAINT "MeasurementTypes_name_key" UNIQUE (name);


--
-- Name: MeasurementTypes MeasurementTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MeasurementTypes"
    ADD CONSTRAINT "MeasurementTypes_pkey" PRIMARY KEY (id);


--
-- Name: MedicalCenters MedicalCenters_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicalCenters"
    ADD CONSTRAINT "MedicalCenters_name_key" UNIQUE (name);


--
-- Name: MedicalCenters MedicalCenters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicalCenters"
    ADD CONSTRAINT "MedicalCenters_pkey" PRIMARY KEY (id);


--
-- Name: MedicalRecords MedicalRecords_patientId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicalRecords"
    ADD CONSTRAINT "MedicalRecords_patientId_key" UNIQUE ("patientId");


--
-- Name: MedicalRecords MedicalRecords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicalRecords"
    ADD CONSTRAINT "MedicalRecords_pkey" PRIMARY KEY (id);


--
-- Name: MessageCancelTypes MessageCancelTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MessageCancelTypes"
    ADD CONSTRAINT "MessageCancelTypes_name_key" UNIQUE (name);


--
-- Name: MessageCancelTypes MessageCancelTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MessageCancelTypes"
    ADD CONSTRAINT "MessageCancelTypes_pkey" PRIMARY KEY (id);


--
-- Name: MessageTypes MessageTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MessageTypes"
    ADD CONSTRAINT "MessageTypes_name_key" UNIQUE (name);


--
-- Name: MessageTypes MessageTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MessageTypes"
    ADD CONSTRAINT "MessageTypes_pkey" PRIMARY KEY (id);


--
-- Name: Messages Messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_pkey" PRIMARY KEY (id);


--
-- Name: NotificationTypes NotificationTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationTypes"
    ADD CONSTRAINT "NotificationTypes_name_key" UNIQUE (name);


--
-- Name: NotificationTypes NotificationTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationTypes"
    ADD CONSTRAINT "NotificationTypes_pkey" PRIMARY KEY (id);


--
-- Name: Notifications Notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_pkey" PRIMARY KEY (id);


--
-- Name: Organizations Organizations_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Organizations"
    ADD CONSTRAINT "Organizations_name_key" UNIQUE (name);


--
-- Name: Organizations Organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Organizations"
    ADD CONSTRAINT "Organizations_pkey" PRIMARY KEY (id);


--
-- Name: ParticipantTypes ParticipantTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParticipantTypes"
    ADD CONSTRAINT "ParticipantTypes_name_key" UNIQUE (name);


--
-- Name: ParticipantTypes ParticipantTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ParticipantTypes"
    ADD CONSTRAINT "ParticipantTypes_pkey" PRIMARY KEY (id);


--
-- Name: Patients Patients_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patients"
    ADD CONSTRAINT "Patients_cedula_key" UNIQUE (cedula);


--
-- Name: Patients Patients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patients"
    ADD CONSTRAINT "Patients_pkey" PRIMARY KEY (id);


--
-- Name: Patients Patients_rif_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patients"
    ADD CONSTRAINT "Patients_rif_key" UNIQUE (rif);


--
-- Name: People People_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."People"
    ADD CONSTRAINT "People_cedula_key" UNIQUE (cedula);


--
-- Name: People People_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."People"
    ADD CONSTRAINT "People_pkey" PRIMARY KEY (id);


--
-- Name: People People_rif_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."People"
    ADD CONSTRAINT "People_rif_key" UNIQUE (rif);


--
-- Name: PersonTimetables PersonTimetables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonTimetables"
    ADD CONSTRAINT "PersonTimetables_pkey" PRIMARY KEY (id);


--
-- Name: PersonTypes PersonTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonTypes"
    ADD CONSTRAINT "PersonTypes_name_key" UNIQUE (name);


--
-- Name: PersonTypes PersonTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonTypes"
    ADD CONSTRAINT "PersonTypes_pkey" PRIMARY KEY (id);


--
-- Name: Pharmacies Pharmacies_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pharmacies"
    ADD CONSTRAINT "Pharmacies_name_key" UNIQUE (name);


--
-- Name: Pharmacies Pharmacies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pharmacies"
    ADD CONSTRAINT "Pharmacies_pkey" PRIMARY KEY (id);


--
-- Name: PostCategories PostCategories_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PostCategories"
    ADD CONSTRAINT "PostCategories_name_key" UNIQUE (name);


--
-- Name: PostCategories PostCategories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PostCategories"
    ADD CONSTRAINT "PostCategories_pkey" PRIMARY KEY (id);


--
-- Name: PostTypes PostTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PostTypes"
    ADD CONSTRAINT "PostTypes_name_key" UNIQUE (name);


--
-- Name: PostTypes PostTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PostTypes"
    ADD CONSTRAINT "PostTypes_pkey" PRIMARY KEY (id);


--
-- Name: Posts Posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Posts"
    ADD CONSTRAINT "Posts_pkey" PRIMARY KEY (id);


--
-- Name: PrePatients PrePatients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PrePatients"
    ADD CONSTRAINT "PrePatients_pkey" PRIMARY KEY (id);


--
-- Name: RatingTypes RatingTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RatingTypes"
    ADD CONSTRAINT "RatingTypes_name_key" UNIQUE (name);


--
-- Name: RatingTypes RatingTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RatingTypes"
    ADD CONSTRAINT "RatingTypes_pkey" PRIMARY KEY (id);


--
-- Name: Ratings Ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ratings"
    ADD CONSTRAINT "Ratings_pkey" PRIMARY KEY (id);


--
-- Name: RequestTypes RequestTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RequestTypes"
    ADD CONSTRAINT "RequestTypes_name_key" UNIQUE (name);


--
-- Name: RequestTypes RequestTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RequestTypes"
    ADD CONSTRAINT "RequestTypes_pkey" PRIMARY KEY (id);


--
-- Name: Requests Requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Requests"
    ADD CONSTRAINT "Requests_pkey" PRIMARY KEY (id);


--
-- Name: Resources Resources_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Resources"
    ADD CONSTRAINT "Resources_name_key" UNIQUE (name);


--
-- Name: Resources Resources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Resources"
    ADD CONSTRAINT "Resources_pkey" PRIMARY KEY (id);


--
-- Name: ResultParameters ResultParameters_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResultParameters"
    ADD CONSTRAINT "ResultParameters_name_key" UNIQUE (name);


--
-- Name: ResultParameters ResultParameters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResultParameters"
    ADD CONSTRAINT "ResultParameters_pkey" PRIMARY KEY (id);


--
-- Name: RiskFactorDiagnoses RiskFactorDiagnoses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RiskFactorDiagnoses"
    ADD CONSTRAINT "RiskFactorDiagnoses_pkey" PRIMARY KEY (id);


--
-- Name: RiskFactors RiskFactors_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RiskFactors"
    ADD CONSTRAINT "RiskFactors_name_key" UNIQUE (name);


--
-- Name: RiskFactors RiskFactors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RiskFactors"
    ADD CONSTRAINT "RiskFactors_pkey" PRIMARY KEY (id);


--
-- Name: Roles Roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_name_key" UNIQUE (name);


--
-- Name: Roles Roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_pkey" PRIMARY KEY (id);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: ServiceRatingTypes ServiceRatingTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceRatingTypes"
    ADD CONSTRAINT "ServiceRatingTypes_pkey" PRIMARY KEY (id);


--
-- Name: ServiceTypes ServiceTypes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceTypes"
    ADD CONSTRAINT "ServiceTypes_name_key" UNIQUE (name);


--
-- Name: ServiceTypes ServiceTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceTypes"
    ADD CONSTRAINT "ServiceTypes_pkey" PRIMARY KEY (id);


--
-- Name: Services Services_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Services"
    ADD CONSTRAINT "Services_name_key" UNIQUE (name);


--
-- Name: Services Services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Services"
    ADD CONSTRAINT "Services_pkey" PRIMARY KEY (id);


--
-- Name: Specialities Specialities_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Specialities"
    ADD CONSTRAINT "Specialities_name_key" UNIQUE (name);


--
-- Name: Specialities Specialities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Specialities"
    ADD CONSTRAINT "Specialities_pkey" PRIMARY KEY (id);


--
-- Name: SystemFunctionRoles SystemFunctionRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemFunctionRoles"
    ADD CONSTRAINT "SystemFunctionRoles_pkey" PRIMARY KEY (id);


--
-- Name: SystemFunctions SystemFunctions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemFunctions"
    ADD CONSTRAINT "SystemFunctions_pkey" PRIMARY KEY (id);


--
-- Name: Timetables Timetables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Timetables"
    ADD CONSTRAINT "Timetables_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key" UNIQUE (username);


--
-- Name: WebContents WebContents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WebContents"
    ADD CONSTRAINT "WebContents_pkey" PRIMARY KEY (id);


--
-- Name: AppointmentHistories AppointmentHistories_appointmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentHistories"
    ADD CONSTRAINT "AppointmentHistories_appointmentId_fkey" FOREIGN KEY ("appointmentId") REFERENCES public."Appointments"(id);


--
-- Name: AppointmentHistories AppointmentHistories_medicalRecordId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AppointmentHistories"
    ADD CONSTRAINT "AppointmentHistories_medicalRecordId_fkey" FOREIGN KEY ("medicalRecordId") REFERENCES public."MedicalRecords"(id);


--
-- Name: Appointments Appointments_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT "Appointments_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patients"(id);


--
-- Name: Appointments Appointments_personId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT "Appointments_personId_fkey" FOREIGN KEY ("personId") REFERENCES public."People"(id);


--
-- Name: Appointments Appointments_prePatientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT "Appointments_prePatientId_fkey" FOREIGN KEY ("prePatientId") REFERENCES public."PrePatients"(id);


--
-- Name: Appointments Appointments_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT "Appointments_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Services"(id);


--
-- Name: Appointments Appointments_timetableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT "Appointments_timetableId_fkey" FOREIGN KEY ("timetableId") REFERENCES public."Timetables"(id);


--
-- Name: Appointments Appointments_typeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Appointments"
    ADD CONSTRAINT "Appointments_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES public."AppointmentTypes"(id);


--
-- Name: AssignedDonatives AssignedDonatives_donativeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssignedDonatives"
    ADD CONSTRAINT "AssignedDonatives_donativeId_fkey" FOREIGN KEY ("donativeId") REFERENCES public."Donatives"(id);


--
-- Name: AssignedDonatives AssignedDonatives_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssignedDonatives"
    ADD CONSTRAINT "AssignedDonatives_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patients"(id);


--
-- Name: Bitacoras Bitacoras_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Bitacoras"
    ADD CONSTRAINT "Bitacoras_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: Comments Comments_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comments"
    ADD CONSTRAINT "Comments_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Posts"(id);


--
-- Name: Comments Comments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comments"
    ADD CONSTRAINT "Comments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: Donations Donations_donativeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Donations"
    ADD CONSTRAINT "Donations_donativeId_fkey" FOREIGN KEY ("donativeId") REFERENCES public."Donatives"(id);


--
-- Name: Donatives Donatives_typeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Donatives"
    ADD CONSTRAINT "Donatives_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES public."DonationTypes"(id);


--
-- Name: EconomicStatuses EconomicStatuses_medicalRecordId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EconomicStatuses"
    ADD CONSTRAINT "EconomicStatuses_medicalRecordId_fkey" FOREIGN KEY ("medicalRecordId") REFERENCES public."MedicalRecords"(id);


--
-- Name: EventContingencies EventContingencies_eventCancelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventContingencies"
    ADD CONSTRAINT "EventContingencies_eventCancelId_fkey" FOREIGN KEY ("eventCancelId") REFERENCES public."EventCancelTypes"(id);


--
-- Name: EventContingencies EventContingencies_eventDetailId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventContingencies"
    ADD CONSTRAINT "EventContingencies_eventDetailId_fkey" FOREIGN KEY ("eventDetailId") REFERENCES public."EventDetails"(id);


--
-- Name: EventDetailPatients EventDetailPatients_eventDetailId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventDetailPatients"
    ADD CONSTRAINT "EventDetailPatients_eventDetailId_fkey" FOREIGN KEY ("eventDetailId") REFERENCES public."EventDetails"(id);


--
-- Name: EventDetailPatients EventDetailPatients_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventDetailPatients"
    ADD CONSTRAINT "EventDetailPatients_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patients"(id);


--
-- Name: EventDetails EventDetails_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventDetails"
    ADD CONSTRAINT "EventDetails_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public."Events"(id);


--
-- Name: EventParticipants EventParticipants_eventDetailId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventParticipants"
    ADD CONSTRAINT "EventParticipants_eventDetailId_fkey" FOREIGN KEY ("eventDetailId") REFERENCES public."EventDetails"(id);


--
-- Name: EventParticipants EventParticipants_participantTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventParticipants"
    ADD CONSTRAINT "EventParticipants_participantTypeId_fkey" FOREIGN KEY ("participantTypeId") REFERENCES public."ParticipantTypes"(id);


--
-- Name: EventParticipants EventParticipants_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventParticipants"
    ADD CONSTRAINT "EventParticipants_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: EventResultParameters EventResultParameters_eventDetailId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventResultParameters"
    ADD CONSTRAINT "EventResultParameters_eventDetailId_fkey" FOREIGN KEY ("eventDetailId") REFERENCES public."EventDetails"(id);


--
-- Name: EventResultParameters EventResultParameters_resultParameterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventResultParameters"
    ADD CONSTRAINT "EventResultParameters_resultParameterId_fkey" FOREIGN KEY ("resultParameterId") REFERENCES public."ResultParameters"(id);


--
-- Name: Events Events_eventTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Events"
    ADD CONSTRAINT "Events_eventTypeId_fkey" FOREIGN KEY ("eventTypeId") REFERENCES public."EventTypes"(id);


--
-- Name: Faqs Faqs_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Faqs"
    ADD CONSTRAINT "Faqs_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organizations"(id);


--
-- Name: GeneralInformations GeneralInformations_webId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GeneralInformations"
    ADD CONSTRAINT "GeneralInformations_webId_fkey" FOREIGN KEY ("webId") REFERENCES public."WebContents"(id);


--
-- Name: GlucoseMeasurements GlucoseMeasurements_measurementTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GlucoseMeasurements"
    ADD CONSTRAINT "GlucoseMeasurements_measurementTypeId_fkey" FOREIGN KEY ("measurementTypeId") REFERENCES public."MeasurementTypes"(id);


--
-- Name: GlucoseMeasurements GlucoseMeasurements_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GlucoseMeasurements"
    ADD CONSTRAINT "GlucoseMeasurements_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patients"(id);


--
-- Name: Guests Guests_eventDetailId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Guests"
    ADD CONSTRAINT "Guests_eventDetailId_fkey" FOREIGN KEY ("eventDetailId") REFERENCES public."EventDetails"(id);


--
-- Name: IllnessDiagnoses IllnessDiagnoses_appointmentHistoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IllnessDiagnoses"
    ADD CONSTRAINT "IllnessDiagnoses_appointmentHistoryId_fkey" FOREIGN KEY ("appointmentHistoryId") REFERENCES public."AppointmentHistories"(id);


--
-- Name: IllnessDiagnoses IllnessDiagnoses_illnessId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."IllnessDiagnoses"
    ADD CONSTRAINT "IllnessDiagnoses_illnessId_fkey" FOREIGN KEY ("illnessId") REFERENCES public."Illnesses"(id);


--
-- Name: LegalGuardians LegalGuardians_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LegalGuardians"
    ADD CONSTRAINT "LegalGuardians_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patients"(id);


--
-- Name: MedicalCenters MedicalCenters_webId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicalCenters"
    ADD CONSTRAINT "MedicalCenters_webId_fkey" FOREIGN KEY ("webId") REFERENCES public."WebContents"(id);


--
-- Name: MedicalRecords MedicalRecords_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MedicalRecords"
    ADD CONSTRAINT "MedicalRecords_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patients"(id);


--
-- Name: Messages Messages_cancelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_cancelId_fkey" FOREIGN KEY ("cancelId") REFERENCES public."MessageCancelTypes"(id);


--
-- Name: Messages Messages_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organizations"(id);


--
-- Name: Messages Messages_typeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES public."MessageTypes"(id);


--
-- Name: Messages Messages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: Notifications Notifications_typeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES public."NotificationTypes"(id);


--
-- Name: Notifications Notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: Patients Patients_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Patients"
    ADD CONSTRAINT "Patients_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: People People_specialityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."People"
    ADD CONSTRAINT "People_specialityId_fkey" FOREIGN KEY ("specialityId") REFERENCES public."Specialities"(id);


--
-- Name: People People_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."People"
    ADD CONSTRAINT "People_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: PersonTimetables PersonTimetables_personId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonTimetables"
    ADD CONSTRAINT "PersonTimetables_personId_fkey" FOREIGN KEY ("personId") REFERENCES public."People"(id);


--
-- Name: PersonTimetables PersonTimetables_timetableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PersonTimetables"
    ADD CONSTRAINT "PersonTimetables_timetableId_fkey" FOREIGN KEY ("timetableId") REFERENCES public."Timetables"(id);


--
-- Name: Pharmacies Pharmacies_webId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pharmacies"
    ADD CONSTRAINT "Pharmacies_webId_fkey" FOREIGN KEY ("webId") REFERENCES public."WebContents"(id);


--
-- Name: Posts Posts_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Posts"
    ADD CONSTRAINT "Posts_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."PostCategories"(id);


--
-- Name: Posts Posts_eventDetailId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Posts"
    ADD CONSTRAINT "Posts_eventDetailId_fkey" FOREIGN KEY ("eventDetailId") REFERENCES public."EventDetails"(id);


--
-- Name: Posts Posts_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Posts"
    ADD CONSTRAINT "Posts_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organizations"(id);


--
-- Name: Posts Posts_postTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Posts"
    ADD CONSTRAINT "Posts_postTypeId_fkey" FOREIGN KEY ("postTypeId") REFERENCES public."PostTypes"(id);


--
-- Name: Ratings Ratings_eventDetailId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ratings"
    ADD CONSTRAINT "Ratings_eventDetailId_fkey" FOREIGN KEY ("eventDetailId") REFERENCES public."EventDetails"(id);


--
-- Name: Ratings Ratings_ratingTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ratings"
    ADD CONSTRAINT "Ratings_ratingTypeId_fkey" FOREIGN KEY ("ratingTypeId") REFERENCES public."RatingTypes"(id);


--
-- Name: Ratings Ratings_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ratings"
    ADD CONSTRAINT "Ratings_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public."Services"(id);


--
-- Name: Ratings Ratings_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ratings"
    ADD CONSTRAINT "Ratings_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: Requests Requests_activityTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Requests"
    ADD CONSTRAINT "Requests_activityTypeId_fkey" FOREIGN KEY ("activityTypeId") REFERENCES public."EventTypes"(id);


--
-- Name: Requests Requests_requestTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Requests"
    ADD CONSTRAINT "Requests_requestTypeId_fkey" FOREIGN KEY ("requestTypeId") REFERENCES public."RequestTypes"(id);


--
-- Name: Requests Requests_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Requests"
    ADD CONSTRAINT "Requests_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: RiskFactorDiagnoses RiskFactorDiagnoses_appointmentHistoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RiskFactorDiagnoses"
    ADD CONSTRAINT "RiskFactorDiagnoses_appointmentHistoryId_fkey" FOREIGN KEY ("appointmentHistoryId") REFERENCES public."AppointmentHistories"(id);


--
-- Name: RiskFactorDiagnoses RiskFactorDiagnoses_riskFactorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RiskFactorDiagnoses"
    ADD CONSTRAINT "RiskFactorDiagnoses_riskFactorId_fkey" FOREIGN KEY ("riskFactorId") REFERENCES public."RiskFactors"(id);


--
-- Name: Services Services_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Services"
    ADD CONSTRAINT "Services_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organizations"(id);


--
-- Name: Services Services_specialityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Services"
    ADD CONSTRAINT "Services_specialityId_fkey" FOREIGN KEY ("specialityId") REFERENCES public."Specialities"(id);


--
-- Name: Services Services_typeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Services"
    ADD CONSTRAINT "Services_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES public."ServiceTypes"(id);


--
-- Name: Specialities Specialities_personTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Specialities"
    ADD CONSTRAINT "Specialities_personTypeId_fkey" FOREIGN KEY ("personTypeId") REFERENCES public."PersonTypes"(id);


--
-- Name: SystemFunctionRoles SystemFunctionRoles_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemFunctionRoles"
    ADD CONSTRAINT "SystemFunctionRoles_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Roles"(id);


--
-- Name: SystemFunctionRoles SystemFunctionRoles_systemFunctionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemFunctionRoles"
    ADD CONSTRAINT "SystemFunctionRoles_systemFunctionId_fkey" FOREIGN KEY ("systemFunctionId") REFERENCES public."SystemFunctions"(id);


--
-- Name: SystemFunctions SystemFunctions_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemFunctions"
    ADD CONSTRAINT "SystemFunctions_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."SystemFunctions"(id);


--
-- Name: Users Users_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Roles"(id);


--
-- PostgreSQL database dump complete
--

